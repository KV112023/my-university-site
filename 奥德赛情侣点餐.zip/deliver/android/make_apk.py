#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把网页打包成 Android APK（WebView 壳）。

沙盒里没有 Android SDK / aapt，所以这里手工生成二进制
AndroidManifest.xml（AXML）与空的 resources.arsc，再用 zip 组装、jarsigner 签名。
"""
import os
import struct
import zipfile
import subprocess
import shutil
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
WEB = os.path.join(BASE, '..', '..', 'odyssey')
OUT = os.path.join(BASE, 'build')

PKG = 'com.odyssey.table'
NS_URI = 'http://schemas.android.com/apk/res/android'

RES_NULL_TYPE = 0x0000
RES_STRING_POOL_TYPE = 0x0001
RES_TABLE_TYPE = 0x0002
RES_XML_TYPE = 0x0003
RES_XML_START_NAMESPACE_TYPE = 0x0100
RES_XML_END_NAMESPACE_TYPE = 0x0101
RES_XML_START_ELEMENT_TYPE = 0x0102
RES_XML_END_ELEMENT_TYPE = 0x0103

TYPE_STRING = 0x03
TYPE_INT_DEC = 0x10
TYPE_INT_BOOLEAN = 0x12
TYPE_REFERENCE = 0x01


# ------------------------------------------------------------------ string pool
class StringPool:
    def __init__(self):
        self.strings = []
        self.index = {}

    def ref(self, s):
        if s is None:
            return 0xFFFFFFFF
        if s not in self.index:
            self.index[s] = len(self.strings)
            self.strings.append(s)
        return self.index[s]

    def build(self):
        """UTF-16 编码的字符串池 chunk"""
        offsets = []
        data = bytearray()
        for s in self.strings:
            offsets.append(len(data))
            enc = s.encode('utf-16-le')
            n = len(enc) // 2
            data += struct.pack('<H', n)
            data += enc
            data += struct.pack('<H', 0)
        # 对齐到 4 字节
        while len(data) % 4 != 0:
            data += b'\x00\x00'

        header_size = 28
        strings_start = header_size + 4 * len(offsets)
        body = bytearray()
        body += struct.pack('<H', 0)
        for off in offsets:
            body += struct.pack('<I', off)
        while len(body) % 4 != 0:
            body += b'\x00'

        pool = bytearray()
        pool += struct.pack('<I', 0)
        for k in range(len(offsets)):
            pool += struct.pack('<I', offsets[k])
        pool += data

        size = header_size + len(pool)
        chunk = struct.pack('<HHIIIIII',
                            RES_STRING_POOL_TYPE, header_size, size,
                            len(self.strings), 0, 0,
                            strings_start, 0)
        return bytes(chunk) + bytes(pool)


def string_pool_chunk(pool):
    offsets = []
    data = bytearray()
    for s in pool.strings:
        offsets.append(len(data))
        enc = s.encode('utf-16-le')
        data += struct.pack('<H', len(enc) // 2)
        data += enc
        data += struct.pack('<H', 0)
    while len(data) % 4 != 0:
        data += b'\x00\x00'

    header_size = 28
    strings_start = header_size + 4 * len(offsets)
    body = bytearray()
    for off in offsets:
        body += struct.pack('<I', off)
    size = header_size + len(body) + len(data)
    chunk = struct.pack('<HHIIIIII',
                        RES_STRING_POOL_TYPE, header_size, size,
                        len(pool.strings), 0, 0, strings_start, 0)
    return bytes(chunk) + bytes(body) + bytes(data)


# ------------------------------------------------------------------ xml chunks
def node(chunk_type, size, line, comment=0xFFFFFFFF):
    return struct.pack('<HHIII', chunk_type, 16, size, line, comment)


def start_ns(pool, prefix, uri, line=2):
    body = struct.pack('<II', pool.ref(prefix), pool.ref(uri))
    size = 24
    return node(RES_XML_START_NAMESPACE_TYPE, size, line) + body


def end_ns(pool, prefix, uri, line=100):
    body = struct.pack('<II', pool.ref(prefix), pool.ref(uri))
    size = 24
    return node(RES_XML_END_NAMESPACE_TYPE, size, line) + body


def res_value(dtype, data):
    return struct.pack('<HBBI', 8, 0, dtype, data & 0xFFFFFFFF)


def start_element(pool, ns, name, attrs, line=3):
    """attrs: list of (ns_uri|None, name, dtype, data, raw_string|None)"""
    ns_i = pool.ref(ns)
    name_i = pool.ref(name)
    attr_bytes = bytearray()
    for (a_ns, a_name, dtype, data, raw) in attrs:
        raw_i = pool.ref(raw)
        attr_bytes += struct.pack('<III', pool.ref(a_ns), pool.ref(a_name), raw_i)
        attr_bytes += res_value(dtype, data)
    size = 36 + len(attr_bytes)
    head = node(RES_XML_START_ELEMENT_TYPE, size, line)
    ext = struct.pack('<IIHHHHHH', ns_i, name_i, 20, 20, len(attrs), 0, 0, 0)
    return head + ext + bytes(attr_bytes)


def end_element(pool, ns, name, line=3):
    body = struct.pack('<II', pool.ref(ns), pool.ref(name))
    return node(RES_XML_END_ELEMENT_TYPE, 24, line) + body


# ------------------------------------------------------------------ manifest
def build_manifest_xml():
    pool = StringPool()

    def a(ns, name, dtype, data, raw=None):
        return (ns, name, dtype, data, raw)

    out = bytearray()
    out += start_ns(pool, 'android', NS_URI)
    out += start_element(pool, None, 'manifest', [
        a(None, 'package', TYPE_STRING, 0, PKG),
        a(NS_URI, 'versionCode', TYPE_INT_DEC, 1, '1'),
        a(NS_URI, 'versionName', TYPE_STRING, 0, '1.0'),
    ])
    # 读图权限：WebChromeClient.onShowFileChooser 走系统选择器拿到的是带
    # 临时读授权的 URI，本身不需要存储权限；这里声明是为了兼容部分 ROM
    # 上 WebView 解析 content:// 时的额外校验。
    out += start_element(pool, None, 'uses-permission', [
        a(NS_URI, 'name', TYPE_STRING, S('android.permission.READ_MEDIA_IMAGES'),
          'android.permission.READ_MEDIA_IMAGES'),
    ])
    out += end_element(pool, None, 'uses-permission')
    out += start_element(pool, None, 'uses-permission', [
        a(NS_URI, 'name', TYPE_STRING, S('android.permission.READ_EXTERNAL_STORAGE'),
          'android.permission.READ_EXTERNAL_STORAGE'),
        a(NS_URI, 'maxSdkVersion', TYPE_INT_DEC, 32, '32'),
    ])
    out += end_element(pool, None, 'uses-permission')
    out += start_element(pool, None, 'uses-sdk', [
        a(NS_URI, 'minSdkVersion', TYPE_INT_DEC, 21, '21'),
        a(NS_URI, 'targetSdkVersion', TYPE_INT_DEC, 30, '30'),
    ])
    out += end_element(pool, None, 'uses-sdk')
    out += start_element(pool, None, 'application', [
        a(NS_URI, 'label', TYPE_STRING, 0, 'ODYSSEY'),
        a(NS_URI, 'hardwareAccelerated', TYPE_INT_BOOLEAN, 0xFFFFFFFF, 'true'),
        a(NS_URI, 'allowBackup', TYPE_INT_BOOLEAN, 0xFFFFFFFF, 'true'),
    ])
    out += start_element(pool, None, 'activity', [
        a(NS_URI, 'label', TYPE_STRING, 0, 'ODYSSEY'),
        a(NS_URI, 'name', TYPE_STRING, 0, '.MainActivity'),
        a(NS_URI, 'screenOrientation', TYPE_INT_DEC, 1, 'portrait'),
        a(NS_URI, 'launchMode', TYPE_INT_DEC, 2, 'singleTask'),
    ])
    out += start_element(pool, None, 'intent-filter', [])
    out += start_element(pool, None, 'action', [
        a(NS_URI, 'name', TYPE_STRING, 0, 'android.intent.action.MAIN'),
    ])
    out += end_element(pool, None, 'action')
    out += start_element(pool, None, 'category', [
        a(NS_URI, 'name', TYPE_STRING, 0, 'android.intent.category.LAUNCHER'),
    ])
    out += end_element(pool, None, 'category')
    out += end_element(pool, None, 'intent-filter')
    out += end_element(pool, None, 'activity')
    out += end_element(pool, None, 'application')
    out += end_element(pool, None, 'manifest')
    out += end_ns(pool, 'android', NS_URI)

    # 字符串属性值需要在池里占位后再回填 data = 字符串索引
    # 做法：先跑一遍收集所有字符串，再重新生成（保证索引稳定）
    return _finalize(pool, out)


def _finalize(pool, out):
    """out 里字符串类属性的 data 尚未填索引，这里重建一次并回填。"""
    # 重放构建过程，这次先把所有字符串加入池，再生成
    return build_manifest_xml_final()


def build_manifest_xml_final():
    pool = StringPool()
    # 先把所有会用到的字符串都登记，保证顺序与第一次一致
    pool.ref('android')
    pool.ref(NS_URI)
    for s in ['manifest', 'package', PKG, 'versionCode', '1', 'versionName', '1.0',
              'uses-permission', 'android.permission.READ_MEDIA_IMAGES',
              'android.permission.READ_EXTERNAL_STORAGE', 'maxSdkVersion', '32',
              'uses-sdk', 'minSdkVersion', '21', 'targetSdkVersion', '30',
              'application', 'label', 'ODYSSEY', 'hardwareAccelerated', 'true',
              'allowBackup', 'activity', 'name', '.MainActivity',
              'screenOrientation', 'portrait', 'launchMode', 'singleTask',
              'intent-filter', 'action', 'android.intent.action.MAIN',
              'category', 'android.intent.category.LAUNCHER']:
        pool.ref(s)

    def S(s):
        return pool.index[s]

    def a(ns, name, dtype, data, raw=None):
        return (ns, name, dtype, data, raw)

    out = bytearray()
    out += start_ns(pool, 'android', NS_URI)
    out += start_element(pool, None, 'manifest', [
        a(None, 'package', TYPE_STRING, S(PKG), PKG),
        a(NS_URI, 'versionCode', TYPE_INT_DEC, 1, '1'),
        a(NS_URI, 'versionName', TYPE_STRING, S('1.0'), '1.0'),
    ])
    # 读图权限：onShowFileChooser 走系统选择器拿到的是带临时读授权的 URI，
    # 本身不需要存储权限；声明是为了兼容部分 ROM 上 WebView 解析
    # content:// 时的额外校验。
    out += start_element(pool, None, 'uses-permission', [
        a(NS_URI, 'name', TYPE_STRING, S('android.permission.READ_MEDIA_IMAGES'),
          'android.permission.READ_MEDIA_IMAGES'),
    ])
    out += end_element(pool, None, 'uses-permission')
    out += start_element(pool, None, 'uses-permission', [
        a(NS_URI, 'name', TYPE_STRING, S('android.permission.READ_EXTERNAL_STORAGE'),
          'android.permission.READ_EXTERNAL_STORAGE'),
        a(NS_URI, 'maxSdkVersion', TYPE_INT_DEC, 32, '32'),
    ])
    out += end_element(pool, None, 'uses-permission')
    out += start_element(pool, None, 'uses-sdk', [
        a(NS_URI, 'minSdkVersion', TYPE_INT_DEC, 21, '21'),
        a(NS_URI, 'targetSdkVersion', TYPE_INT_DEC, 30, '30'),
    ])
    out += end_element(pool, None, 'uses-sdk')
    out += start_element(pool, None, 'application', [
        a(NS_URI, 'label', TYPE_STRING, S('ODYSSEY'), 'ODYSSEY'),
        a(NS_URI, 'hardwareAccelerated', TYPE_INT_BOOLEAN, 0xFFFFFFFF, 'true'),
        a(NS_URI, 'allowBackup', TYPE_INT_BOOLEAN, 0xFFFFFFFF, 'true'),
    ])
    out += start_element(pool, None, 'activity', [
        a(NS_URI, 'label', TYPE_STRING, S('ODYSSEY'), 'ODYSSEY'),
        a(NS_URI, 'name', TYPE_STRING, S('.MainActivity'), '.MainActivity'),
        a(NS_URI, 'screenOrientation', TYPE_INT_DEC, 1, 'portrait'),
        a(NS_URI, 'launchMode', TYPE_INT_DEC, 2, 'singleTask'),
    ])
    out += start_element(pool, None, 'intent-filter', [])
    out += start_element(pool, None, 'action', [
        a(NS_URI, 'name', TYPE_STRING, S('android.intent.action.MAIN'),
          'android.intent.action.MAIN'),
    ])
    out += end_element(pool, None, 'action')
    out += start_element(pool, None, 'category', [
        a(NS_URI, 'name', TYPE_STRING, S('android.intent.category.LAUNCHER'),
          'android.intent.category.LAUNCHER'),
    ])
    out += end_element(pool, None, 'category')
    out += end_element(pool, None, 'intent-filter')
    out += end_element(pool, None, 'activity')
    out += end_element(pool, None, 'application')
    out += end_element(pool, None, 'manifest')
    out += end_ns(pool, 'android', NS_URI)

    body = bytes(out)
    pool_chunk = string_pool_chunk(pool)
    total = 8 + len(pool_chunk) + len(body)
    header = struct.pack('<HHI', RES_XML_TYPE, 8, total)
    return header + pool_chunk + body


def build_empty_arsc():
    """一个合法但空的 resource table（packageCount = 0）"""
    return struct.pack('<HHII', RES_TABLE_TYPE, 12, 12, 0)


# ------------------------------------------------------------------ assemble
def main():
    os.makedirs(OUT, exist_ok=True)

    manifest = build_manifest_xml_final()
    with open(os.path.join(OUT, 'AndroidManifest.xml'), 'wb') as f:
        f.write(manifest)
    print('AndroidManifest.xml: %d bytes' % len(manifest))

    arsc = build_empty_arsc()
    with open(os.path.join(OUT, 'resources.arsc'), 'wb') as f:
        f.write(arsc)

    dex = os.path.join(BASE, 'classes.dex')
    if not os.path.exists(dex):
        sys.exit('缺少 classes.dex')

    unsigned = os.path.join(OUT, 'unsigned.apk')
    if os.path.exists(unsigned):
        os.remove(unsigned)

    files = []  # (arcname, path)
    files.append(('AndroidManifest.xml', os.path.join(OUT, 'AndroidManifest.xml')))
    files.append(('resources.arsc', os.path.join(OUT, 'resources.arsc')))
    files.append(('classes.dex', dex))
    # 顺序与 index.html 里的 <script> 一致
    webfiles = ['index.html', 'motion.js', 'morph.js', 'intro.js', 'geo-data.js', 'map.js', 'sync.js',
                'liquid-glass.js', 'fluid.js', 'app.js',
                'manifest.json', 'sw.js', 'README.md']
    for icon in ['icon-192.png', 'icon-512.png', 'maskable-192.png', 'maskable-512.png']:
        p = os.path.join(WEB, 'icons', icon)
        if os.path.exists(p):
            files.append(('assets/icons/' + icon, p))
    for name in webfiles:
        p = os.path.join(WEB, name)
        if os.path.exists(p):
            files.append(('assets/' + name, p))

    with zipfile.ZipFile(unsigned, 'w', zipfile.ZIP_DEFLATED) as z:
        for arc, path in files:
            z.write(path, arc)
    print('unsigned.apk: %d bytes, %d entries' % (len(files), len(files)))

    # ---------------- 签名（v1 / JAR 签名，openssl 实现） ----------------
    # 沙盒里没有 jarsigner，这里按 AOSP signapk 的格式手工生成
    # META-INF/MANIFEST.MF、ODYSSEY.SF，并用 openssl 产出 PKCS#7 签名块。
    import base64
    import hashlib

    def b64(b):
        return base64.b64encode(b).decode('ascii')

    def mf_section(name, digest_b64):
        return ('Name: ' + name + '\r\n' +
                'SHA1-Digest: ' + digest_b64 + '\r\n' +
                '\r\n').encode('utf-8')

    # 需要被签名覆盖的文件（META-INF 下的由系统跳过）
    signed = [(arc, path) for arc, path in files]
    signed.sort(key=lambda x: x[0])

    mf = b'Manifest-Version: 1.0\r\nCreated-By: 1.0 (ODYSSEY)\r\n\r\n'
    sections = {}
    for arc, path in signed:
        data = open(path, 'rb').read()
        d = b64(hashlib.sha1(data).digest())
        sec = mf_section(arc, d)
        sections[arc] = sec
        mf += sec

    sf = b'Signature-Version: 1.0\r\nCreated-By: 1.0 (ODYSSEY)\r\n'
    sf += ('SHA1-Digest-Manifest: ' + b64(hashlib.sha1(mf).digest()) +
           '\r\n').encode('ascii')
    sf += b'\r\n'
    for arc, _ in signed:
        sec = sections[arc]
        sf += mf_section(arc, b64(hashlib.sha1(sec).digest()))

    tmpdir = os.path.join(OUT, 'meta')
    shutil.rmtree(tmpdir, ignore_errors=True)
    os.makedirs(tmpdir)
    mf_path = os.path.join(tmpdir, 'MANIFEST.MF')
    sf_path = os.path.join(tmpdir, 'ODYSSEY.SF')
    rsa_path = os.path.join(tmpdir, 'ODYSSEY.RSA')
    open(mf_path, 'wb').write(mf)
    open(sf_path, 'wb').write(sf)

    key_pem = os.path.join(OUT, 'key.pem')
    cert_pem = os.path.join(OUT, 'cert.pem')
    for f in (key_pem, cert_pem):
        if os.path.exists(f):
            os.remove(f)
    subprocess.run([
        'openssl', 'req', '-x509', '-newkey', 'rsa:2048', '-nodes',
        '-keyout', key_pem, '-out', cert_pem, '-days', '10950',
        '-subj', '/CN=ODYSSEY/OU=Table/O=Odyssey/L=Ithaca/ST=Sea/C=CN',
    ], check=True, capture_output=True)

    r = subprocess.run([
        'openssl', 'smime', '-sign', '-binary', '-noattr', '-outform', 'DER',
        '-md', 'sha1', '-in', sf_path, '-out', rsa_path,
        '-signer', cert_pem, '-inkey', key_pem,
    ], capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(rsa_path):
        print(r.stdout, r.stderr)
        sys.exit('生成签名块失败')
    print('signature block: %d bytes' % os.path.getsize(rsa_path))

    # 最终 APK：所有文件 + META-INF 三件套
    signed_apk = os.path.join(OUT, 'odyssey.apk')
    if os.path.exists(signed_apk):
        os.remove(signed_apk)
    with zipfile.ZipFile(signed_apk, 'w', zipfile.ZIP_DEFLATED) as z:
        for arc, path in signed:
            z.write(path, arc)
        z.write(mf_path, 'META-INF/MANIFEST.MF')
        z.write(sf_path, 'META-INF/ODYSSEY.SF')
        z.write(rsa_path, 'META-INF/ODYSSEY.RSA')
    print('v1 signed: %d bytes, %d entries' % (
        os.path.getsize(signed_apk),
        len(signed) + 3,
    ))

    # ---------------- v2 签名（Android 11+ 必需） ----------------
    from cryptography.hazmat.primitives import serialization
    sys.path.insert(0, BASE)
    import signv2

    from cryptography import x509
    with open(cert_pem, 'rb') as f:
        cert = x509.load_pem_x509_certificate(f.read())
    with open(key_pem, 'rb') as f:
        key = serialization.load_pem_private_key(f.read(), password=None)
    cert_der = cert.public_bytes(serialization.Encoding.DER)

    with open(signed_apk, 'rb') as f:
        v1_bytes = f.read()
    v2_bytes = signv2.sign_v2(v1_bytes, cert_der, key)
    with open(signed_apk, 'wb') as f:
        f.write(v2_bytes)

    ok, msg = signv2.verify_layout(v2_bytes)
    if not ok:
        sys.exit('v2 签名块自检失败：' + msg)
    print('v2 signing block:', msg)
    print('odyssey.apk: %d bytes' % os.path.getsize(signed_apk))


if __name__ == '__main__':
    main()
