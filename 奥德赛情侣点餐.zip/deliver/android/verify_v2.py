#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""按 AOSP ApkSignatureSchemeV2Verifier 的规则独立校验 v2 签名。

不依赖打包脚本的任何状态：重新解析 APK、重算三段 Merkle 摘要、
用块里的公钥验签，并核对公钥与证书是否配对。
"""
import hashlib
import struct
import sys

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa, ec

CHUNK = 1048576
V2_ID = 0x7109871A
MAGIC = b'APK Sig Block 42'


def u32(b, i):
    return struct.unpack_from('<I', b, i)[0]


def u64(b, i):
    return struct.unpack_from('<Q', b, i)[0]


def find_eocd(apk):
    n = len(apk)
    for pos in range(n - 22, max(-1, n - 22 - 65535), -1):
        if apk[pos:pos + 4] == b'PK\x05\x06':
            cl = struct.unpack('<H', apk[pos + 20:pos + 22])[0]
            if pos + 22 + cl == n:
                return pos
    raise ValueError('EOCD 未找到')


def chunked(data):
    parts = []
    if not data:
        parts.append(hashlib.sha256(b'\xa5' + struct.pack('<I', 0)).digest())
    else:
        for i in range(0, len(data), CHUNK):
            c = data[i:i + CHUNK]
            parts.append(hashlib.sha256(b'\xa5' + struct.pack('<I', len(c)) + c).digest())
    return hashlib.sha256(b'\x5a' + struct.pack('<I', len(parts)) + b''.join(parts)).digest()


def seq_elements(buf, start, end):
    """解析 'sequence of uint32-length-prefixed elements'，返回 [(start,end)]"""
    out = []
    i = start
    while i < end:
        ln = u32(buf, i)
        s = i + 4
        e = s + ln
        if e > end:
            raise ValueError('序列元素越界')
        out.append((s, e))
        i = e
    if i != end:
        raise ValueError('序列长度不整')
    return out


def main(path):
    apk = open(path, 'rb').read()
    eocd = find_eocd(apk)
    cd_size = u32(apk, eocd + 12)
    cd_offset = u32(apk, eocd + 16)   # 已指向 Signing Block 之后

    magic_pos = cd_offset - len(MAGIC)
    if magic_pos < 0 or apk[magic_pos:magic_pos + len(MAGIC)] != MAGIC:
        print('FAIL: magic 缺失'); return 1
    size2 = u64(apk, magic_pos - 8)
    block_start = magic_pos + 8 - size2      # 块总长 = 8 + size
    size1 = u64(apk, block_start)
    if size1 != size2:
        print('FAIL: 块大小不一致'); return 1
    if block_start + 8 + size2 != cd_offset:
        print('FAIL: 块边界不对'); return 1
    print('OK  signing block 位置正确 (%d 字节)' % (cd_offset - block_start))

    # 取 v2 pair
    pos, end = block_start + 8, magic_pos - 8
    value = None
    while pos + 12 <= end:
        plen = u64(apk, pos)
        pid = u32(apk, pos + 8)
        if pid == V2_ID:
            value = apk[pos + 12:pos + 8 + plen]
            break
        pos += 8 + plen
    if value is None:
        print('FAIL: 找不到 v2 pair'); return 1
    print('OK  找到 v2 签名 (ID 0x%08x)' % V2_ID)

    # signers 序列
    total = u32(value, 0)
    if total != len(value) - 4:
        print('FAIL: signers 序列长度不符'); return 1
    signers = seq_elements(value, 4, len(value))
    print('OK  signer 数量: %d' % len(signers))

    # 重算三段摘要
    before = apk[:block_start]
    central = apk[cd_offset:cd_offset + cd_size]
    tail = bytearray(apk[eocd:])
    struct.pack_into('<I', tail, 16, block_start)
    expected = [chunked(before), chunked(central), chunked(bytes(tail))]
    labels = ['ZIP entries', 'Central Directory', 'EOCD']

    for si, (ss, se) in enumerate(signers):
        i = ss
        sd_len = u32(value, i); i += 4
        sd_start = i
        sd = value[i:i + sd_len]; i += sd_len

        sig_len = u32(value, i); i += 4
        sigs = seq_elements(value, i, i + sig_len); i += sig_len

        pk_len = u32(value, i); i += 4
        pubkey_der = value[i:i + pk_len]; i += pk_len
        if i != se:
            print('FAIL: signer %d 解析后位置不符' % si); return 1

        # --- signed data 内部 ---
        d_len = u32(sd, 0)
        digests = seq_elements(sd, 4, 4 + d_len)
        c_len = u32(sd, 4 + d_len)
        certs = seq_elements(sd, 8 + d_len, 8 + d_len + c_len)
        a_len = u32(sd, 8 + d_len + c_len)
        attr_end = 12 + d_len + c_len + a_len
        if attr_end != len(sd):
            print('FAIL: signed data 长度不符'); return 1

        if len(digests) != 3:
            print('FAIL: 摘要段数应为 3，实为 %d' % len(digests)); return 1
        for k, (ds, de) in enumerate(digests):
            algo = u32(sd, ds)
            dlen = u32(sd, ds + 4)
            got = sd[ds + 8:ds + 8 + dlen]
            ok = got == expected[k]
            print('%s 摘要 %-18s algo=0x%04x %s' % (
                'OK ' if ok else 'FAIL', labels[k], algo, '匹配' if ok else '不匹配'))
            if not ok:
                return 1

        # --- 证书 / 公钥配对 ---
        cert_der = sd[certs[0][0]:certs[0][1]]
        cert = x509.load_der_x509_certificate(cert_der)
        cert_pk = cert.public_key().public_bytes(
            serialization.Encoding.DER,
            serialization.PublicFormat.SubjectPublicKeyInfo)
        if cert_pk != pubkey_der:
            print('FAIL: 块内公钥与证书公钥不一致'); return 1
        print('OK  公钥与证书配对（%s，有效期至 %s）'
              % (cert.public_key().__class__.__name__.replace('_', ' '),
                 cert.not_valid_after_utc.date()))

        # --- 验签 ---
        for (gs, ge) in sigs:
            algo = u32(value, gs)
            slen = u32(value, gs + 4)
            sig = value[gs + 8:gs + 8 + slen]
            pub = serialization.load_der_public_key(pubkey_der)
            try:
                if isinstance(pub, rsa.RSAPublicKey):
                    pub.verify(sig, sd, padding.PKCS1v15(), hashes.SHA256())
                elif isinstance(pub, ec.EllipticCurvePublicKey):
                    pub.verify(sig, sd, ec.ECDSA(hashes.SHA256()))
                else:
                    print('FAIL: 不支持的公钥类型'); return 1
                print('OK  签名校验通过 (algo=0x%04x, %d 字节)' % (algo, slen))
            except Exception as e:
                print('FAIL: 签名校验失败 -> %s' % e)
                return 1
            break

    print('\n== v2 签名全部校验通过 ==')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else 'build/odyssey.apk'))
