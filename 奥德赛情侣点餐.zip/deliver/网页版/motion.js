/* ==================================================================
 * MOTION —— 非线性缓动 + 动态模糊
 *
 * 两条设计约束（决定了实现方式，先说清楚）：
 *
 * ① 为什么「动态模糊」不是真的模糊
 *    渲染器把每个元素烘焙进一张 elFbo，`blurRadius` **在缓存签名里**
 *    （elementCacheSignature 第 4654 行）。每帧改它就会 cache miss，
 *    每帧重烘焙一遍玻璃体 —— 一帧几十次模糊 pass，直接卡死。
 *    所以真正的逐帧模糊在这里不可行。
 *
 *    改用动画界的标准等价物：**沿运动方向的各向异性拉伸（smear）**。
 *    快速移动时沿速度方向拉长、垂直方向略收窄，观感上就是拖影。
 *    关键在于 `elementScaleX/Y` **不在缓存签名里**（渲染器注释明确说
 *    "deliberately excluded ... elFbo stays at baseline resolution"），
 *    所以每帧改它零成本，不需要重烘焙。
 *
 * ② 渲染器内建的过冲形变
 *    enterProgress > 1 时渲染器会自动做 squash & stretch：
 *      derived = 1 + (1 - exp(-(raw-1)))
 *      translationY += -48dp * (1 - derived)      // 越过终点继续下落
 *      sFactor = 1 + 0.1 * (derived - 1)          // 纵向拉伸、横向压缩
 *    原来的缓动被夹在 [0,1]，这段永远触发不到。改用带过冲的曲线后，
 *    落位末段会自动获得弹性形变 —— 这就是入场的"动态模糊"。
 *
 *    另：enterSafeProgress 被渲染器内部 clamp 到 [0,1]，
 *    所以可以安全地让 enterProgress 过冲而透明度不过冲。
 * ================================================================== */
(function (global) {
  'use strict'

  const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v)

  /* ================================================================ *
   * 非线性缓动
   * ================================================================ */
  const Ease = {
    linear: (t) => clamp01(t),

    /** 末段很长很缓 —— 最通用的"滑到位"。 */
    outCubic: (t) => { t = clamp01(t); return 1 - Math.pow(1 - t, 3) },

    outQuint: (t) => { t = clamp01(t); return 1 - Math.pow(1 - t, 5) },

    outExpo: (t) => { t = clamp01(t); return t >= 1 ? 1 : 1 - Math.pow(2, -10 * t) },

    inOutCubic: (t) => {
      t = clamp01(t)
      return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2
    },

    /** 两端都缓 —— 用于"消失"和"互换"这类对称过渡。 */
    smoothstep: (t) => { t = clamp01(t); return t * t * (3 - 2 * t) },

    /**
     * 越过 1 再回落。过冲段就是渲染器 squash & stretch 的触发区，
     * 所以这条曲线同时给了「弹性落位」和「末段形变」。
     * k 越大过冲越猛（1.9 ≈ 过冲 11%，2.6 ≈ 过冲 16%）。
     */
    outBack: (t, k) => {
      t = clamp01(t)
      const s = (k == null ? 1.9 : k)
      const u = t - 1
      return 1 + (s + 1) * u * u * u + s * u * u
    },

    /** 阻尼震荡：末段来回收敛几下。比 outBack 更"弹"，但要克制着用。 */
    outElastic: (t, amp) => {
      t = clamp01(t)
      if (t <= 0) return 0
      if (t >= 1) return 1
      const p = 0.44
      const a = (amp == null ? 1 : amp)
      return 1 - a * Math.pow(2, -9 * t) * Math.cos((t - p / 4) * (2 * Math.PI) / p)
    },
  }

  /**
   * 帧率无关的指数趋近。
   * 直接写 `v += (target - v) * 0.2` 在不同帧率下速度完全不同，
   * 60fps 和 120fps 的感受会差一倍。用 dt 换算才一致。
   */
  function approach(current, target, halfLifeMs, dtMs) {
    if (!(halfLifeMs > 0) || !(dtMs > 0)) return target
    const k = 1 - Math.pow(0.5, dtMs / halfLifeMs)
    return current + (target - current) * k
  }

  /* ================================================================ *
   * 动态模糊（速度自适应拉伸）
   * ================================================================ */
  const MB_DEFAULTS = {
    /** 达到这个速度时拉伸到上限（CSS px / s）。 */
    refSpeed: 1500,
    /** 沿运动方向最多拉伸这么多（比例）。 */
    maxStretch: 0.11,
    /** 垂直方向按这个比例收窄，避免元素整体变大。 */
    squash: 0.38,
    /** 速度平滑的半衰期（ms）。太短会抖，太长会有拖尾残留。 */
    smoothMs: 55,
    /** 低于这个速度就不形变，避免静止时的亚像素抖动被放大。 */
    minSpeed: 30,
    /** dt 下限（ms）。两帧挨太近时速度会算得离谱。 */
    minDt: 6,
    /** 只有这些 shape 参与形变。text 不参与 —— 文字拉伸很难看。 */
    deformable: { 'glass-shape': 1, 'button': 1, 'plain-rect': 1 },
  }

  function MotionBlur(opts) {
    const o = Object.assign({}, MB_DEFAULTS, opts || {})
    /** id -> { x, y, t, vx, vy } */
    const prev = new Map()
    let lastT = 0
    let active = false

    return {
      options: o,

      /**
       * @param {Array} elements 本帧的元素（会被就地写上 elementScaleX/Y）
       * @param {Object} ctx
       *   ctx.now        时间戳（ms）
       *   ctx.velocity   [vx, vy] 外部注入的整体速度（滚动惯性），px/s
       *                  只作用于 el.scroll 为真的元素
       * @returns {Boolean} 是否还有元素在形变（调用方据此决定是否继续出帧）
       */
      apply: function (elements, ctx) {
        const now = (ctx && ctx.now) || 0
        const inv = (ctx && ctx.velocity) || null
        const dtReal = lastT ? (now - lastT) : 0
        // 间隔过长（切后台回来、很久没出帧）时，这中间的位移不是
        // "运动"，不能当速度用 —— 否则一次布局跳变就能瞬间拉满形变。
        // 注意：不能用"把 dt 压小"来规避，那反而会让速度变得更大。
        const stale = dtReal > 120
        let dt = dtReal < o.minDt ? o.minDt : dtReal
        lastT = now

        const alive = new Set()
        let any = false

        for (const el of elements) {
          if (!el || !el.rect) continue
          alive.add(el.id)

          // 底部标签栏有自己的变换逻辑（容器缩放、指示器弹簧），
          // 再叠一层运动会互相打架。
          if (el.isBottomTabContainer || el.isBottomTabContent || el.isBottomTabIndicator) continue
          if (!o.deformable[el.shape]) continue

          const cx = el.rect.x + el.rect.w / 2
          const cy = el.rect.y + el.rect.h / 2

          let vx = 0
          let vy = 0
          const p = prev.get(el.id)
          if (p && !stale) {
            vx = (cx - p.x) / (dt / 1000)
            vy = (cy - p.y) / (dt / 1000)
          }
          // 滚动是渲染器内部的平移，rect 不变，自身速度算不出来，
          // 所以外部注入。
          if (inv && el.scroll) {
            vx += inv[0] || 0
            vy += inv[1] || 0
          }

          const sv = p ? p : { vx: 0, vy: 0 }
          const nvx = approach(sv.vx, vx, o.smoothMs, dt)
          const nvy = approach(sv.vy, vy, o.smoothMs, dt)

          prev.set(el.id, { x: cx, y: cy, t: now, vx: nvx, vy: nvy })

          const speed = Math.sqrt(nvx * nvx + nvy * nvy)
          if (speed < o.minSpeed) {
            // 归位。不清 prev，否则下次运动的第一帧会被当成"没动过"。
            if (el.elementScaleX != null || el.elementScaleY != null) {
              el.elementScaleX = undefined
              el.elementScaleY = undefined
            }
            continue
          }

          any = true
          const k = o.maxStretch * Math.min(1, speed / o.refSpeed)
          const ux = speed > 0 ? Math.abs(nvx) / speed : 0
          const uy = speed > 0 ? Math.abs(nvy) / speed : 0
          // 沿运动方向拉长，垂直方向略收窄
          const sx = 1 + k * ux - k * o.squash * uy
          const sy = 1 + k * uy - k * o.squash * ux

          el.elementScaleX = (el.elementScaleX == null ? 1 : el.elementScaleX) * sx
          el.elementScaleY = (el.elementScaleY == null ? 1 : el.elementScaleY) * sy
        }

        // 清掉这一帧不再存在的元素，否则 Map 会一直涨
        if (prev.size > alive.size) {
          for (const id of Array.from(prev.keys())) {
            if (!alive.has(id)) prev.delete(id)
          }
        }

        active = any
        return any
      },

      /** 上一帧结束时是否仍在形变。 */
      isActive: function () { return active },

      /** 让追踪器归零（切换页面时用，避免把布局跳变当成运动）。 */
      reset: function () {
        prev.clear()
        lastT = 0
        active = false
      },

      /** 元素数量，仅供诊断。 */
      tracked: function () { return prev.size },
    }
  }

  global.Motion = {
    Ease: Ease,
    approach: approach,
    MotionBlur: MotionBlur,
    clamp01: clamp01,
  }
})(typeof window !== 'undefined' ? window : globalThis)
