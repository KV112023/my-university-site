#!/usr/bin/env python3
"""把整个工程打包成一个自包含的 HTML 文件。

为什么需要它：
  - 沙盒有期限，多文件工程容易丢，单文件更容易长期保管
    （邮件附件、网盘、备忘录都放得下）
  - 回档时只要把这一个文件给我（或上传后给我链接），就能还原全部源码
  - 双击即跑，不依赖同目录里的其他文件

做法：把 app.js / motion.js / fluid.js / liquid-glass.js 内联进 index.html，
去掉 manifest 与 Service Worker 的注册（单文件下它们没有意义）。

用法：  python3 bundle.py [输出文件]
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = ['app.js', 'motion.js', 'fluid.js', 'liquid-glass.js']
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, 'odyssey-standalone.html')

html = open(os.path.join(HERE, 'index.html'), encoding='utf-8').read()

# 1) 去掉 manifest / Service Worker：单文件下这两个都指向不存在的东西。
#    同时留一个标记，让 unbundle.py 知道要补回来。
html = re.sub(r'<link rel="manifest"[^>]*>\n?', '', html)
html = re.sub(
    r'\s*// 离线缓存（file:// 下注册会失败，静默忽略）\s*\n'
    r"\s*if \('serviceWorker' in navigator.*?\n\s*\}\s*\n",
    '\n', html, flags=re.S)

# 2) 把每个 <script src="x.js"> 换成内联
count = 0
for name in SRC:
    path = os.path.join(HERE, name)
    if not os.path.exists(path):
        print('!! 缺少 ' + name)
        sys.exit(1)
    code = open(path, encoding='utf-8').read()
    pat = r'<script src="' + re.escape(name) + r'"></script>'
    if not re.search(pat, html):
        print('!! index.html 里没有引用 ' + name)
        sys.exit(1)
    # </script> 出现在 JS 字符串里会提前闭合脚本块，必须转义
    safe = code.replace('</script', '<\\/script')
    # 加来源标记，反向解包时才能认出哪个块是哪个文件
    marker = '/* ==== BUNDLE_FILE: %s ==== */\n' % name
    html = re.sub(pat, lambda m: '<script>\n' + marker + safe + '\n</script>', html, count=1)
    count += 1
    print('  内联 %-18s %7d 字节' % (name, len(code)))

# 内联之后不应该还有外部 js 引用（-icons 之类是图片，不受影响）
left = re.findall(r'<script src="([^"]+)"', html)
if left:
    print('!! 仍有未内联的外部脚本: ' + ', '.join(left))
    sys.exit(1)

open(OUT, 'w', encoding='utf-8').write(html)
size = os.path.getsize(OUT)
print('==> %s' % OUT)
print('    共 %d 字节（%.0f KB），双击即可运行' % (size, size / 1024.0))
print('    已内联 %d 个脚本；manifest / Service Worker 已移除' % count)
