#!/usr/bin/env bash
# ==================================================================
# 回档脚本 —— 沙盒崩了、本地数据丢了之后，从 GitHub 拉回完整工程
#
# 用法：
#   ./restore.sh                    # 拉默认的仓库
#   ./restore.sh <仓库地址> [分支]    # 拉指定仓库
#
# 它会把仓库克隆到 ./odyssey-restored，然后校验关键文件是否齐全。
# 拉下来之后直接打开 odyssey-restored/index.html 即可运行。
# ==================================================================
set -euo pipefail

REPO="${1:-https://github.com/YOUR_NAME/odyssey-table.git}"
# 不写死分支名：GitHub 默认分支可能是 main 也可能是 master
BRANCH="${2:-}"
DEST="${3:-./odyssey-restored}"

# ---- 也支持直接给一个 raw 文件链接（Gist / jsdelivr / raw.githubusercontent）----
# 这种形式不需要 git，也不需要建仓库，最省事。
case "$REPO" in
  *gist.githubusercontent.com*|*cdn.jsdelivr.net*|*raw.githubusercontent.com*|*objects.githubusercontent.com*)
    echo "==> 检测到 raw 链接，直接下载到 ${DEST}.html"
    curl -fsSL "$REPO" -o "${DEST}.html" || { echo "!! 下载失败"; exit 1; }
    echo "==> 下载完成（$(wc -c < "${DEST}.html") 字节）"
    echo "==> 直接用浏览器打开：${DEST}.html"
    exit 0
    ;;
esac

echo "==> 从 $REPO ${BRANCH:+(分支 $BRANCH)} 回档到 $DEST"

if [ -d "$DEST" ]; then
  echo "!! $DEST 已存在，先移开"
  mv "$DEST" "$DEST.bak.$(date +%s)"
fi

if command -v git >/dev/null 2>&1; then
  if [ -n "$BRANCH" ]; then
    git clone --depth 1 --branch "$BRANCH" "$REPO" "$DEST"
  else
    git clone --depth 1 "$REPO" "$DEST"
  fi
else
  # 没有 git 时退化为下载 tarball
  echo "!! 没有 git，改用 tarball 下载"
  mkdir -p "$DEST"
  # 先试 main，再试 master
  for b in "${BRANCH:-main}" master; do
    TARBALL="${REPO%.git}/archive/refs/heads/$b.tar.gz"
    if curl -fsSL "$TARBALL" | tar -xz -C "$DEST" --strip-components=1; then
      break
    fi
  done
fi

# ---- 校验：少一个都跑不起来 ----
REQUIRED="index.html app.js fluid.js liquid-glass.js motion.js manifest.json sw.js"
missing=""
for f in $REQUIRED; do
  if [ ! -f "$DEST/$f" ]; then missing="$missing $f"; fi
done

if [ -n "$missing" ]; then
  echo "!! 回档不完整，缺少：$missing"
  exit 1
fi

echo "==> 回档完成，关键文件齐全："
ls -la "$DEST" | sed 's/^/    /'
echo
echo "==> 直接打开即可运行：  $DEST/index.html"
echo "==> 重新打 APK：        cd $DEST/android && ./build.sh"
