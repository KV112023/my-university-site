/* ==================================================================
 * ODYSSEY — 两个人的餐桌
 * 仿《奥德赛》美学的情侣点餐小站
 * 玻璃质感来自 liquid-glass-webgl (martin65536) 的 WebGL 渲染器
 * ================================================================== */

/* ------------------------------------------------------------------ *
 * 调色板 —— 爱琴海的夜、青铜与蜜金
 * ------------------------------------------------------------------ */
const C = {
  gold: [0.94, 0.78, 0.45, 1],
  goldSoft: [0.94, 0.78, 0.45, 0.72],
  goldDim: [0.94, 0.78, 0.45, 0.34],
  cream: [1, 1, 1, 1],
  creamSoft: [1, 1, 1, 0.72],
  creamDim: [1, 1, 1, 0.46],
  bronze: [0.72, 0.47, 0.26, 1],
  deep: [0.04, 0.07, 0.13, 1],
  glassDark: [0.05, 0.08, 0.14, 0.42],
  glassWarm: [0.16, 0.09, 0.05, 0.45],
  scrim: [0.02, 0.03, 0.06, 0.55],
}

const HL = { mode: 0, color: [1, 1, 1], angle: Math.PI / 4, falloff: 1, alpha: 0.5, widthDp: 0.5 }
const HL_GOLD = { mode: 0, color: [1, 0.92, 0.72], angle: Math.PI / 4, falloff: 1, alpha: 0.55, widthDp: 0.6 }
const SHADOW = { radius: 24, alpha: 0.18, offsetX: 0, offsetY: 6, color: [0, 0, 0] }
const SHADOW_SOFT = { radius: 18, alpha: 0.12, offsetX: 0, offsetY: 4, color: [0, 0, 0] }

/* ------------------------------------------------------------------ *
 * 菜单与人物
 * ------------------------------------------------------------------ */
/**
 * 默认菜单。用户可以整个改掉（增删改名/描述/价格），
 * 这份只作为首次打开的样子和「恢复默认」的依据。
 */
const DEFAULT_MENU = [
  { id: 'd1', name: '伊萨卡烤羊排', desc: '迷迭香 · 海盐 · 慢火炙烤', price: 168 },
  { id: 'd2', name: '爱琴海海鲜拼盘', desc: '当日现捕 · 柠檬与白葡萄酒', price: 198 },
  { id: 'd3', name: '蜜渍奶酪与无花果', desc: '织机旁的甜 · 百里香蜂蜜', price: 58 },
  { id: 'd4', name: '独眼巨人炭烤章鱼', desc: '炭火焦香 · 初榨橄榄油', price: 128 },
  { id: 'd5', name: '塞壬藏红花意面', desc: '青口贝 · 藏红花细面', price: 88 },
  { id: 'd6', name: '归乡桑格利亚', desc: '红酒 · 柑橘 · 肉桂', price: 68 },
]

/* ------------------------------------------------------------------ *
 * 自定义菜单
 * ------------------------------------------------------------------ */
const MENU_LIMIT = 24          // 再多网格就撑爆了
const DISH_IMG_MAX = 240 * 1024   // 单张图的 dataURL 上限（base64 后约 180KB 原图）
const STORE_BUDGET = 3.5 * 1024 * 1024   // localStorage 一般 5MB，留点余量

/** 存档是否超出预算。图片是主要风险点，写之前先估一次。 */
function storeTooBig() {
  try {
    const s = JSON.stringify(buildSaveData())
    return s.length > STORE_BUDGET
  } catch (e) { return false }
}
const NAME_MAX = 20
const DESC_MAX = 30
const PRICE_MAX = 99999

/** 当前菜单。之所以不直接用常量，是因为它整个可编辑。 */
function menu() { return state.menu }

function cloneMenu(list) {
  return (list || []).map(function (d) {
    return {
      id: d.id, name: d.name, desc: d.desc || '',
      price: Number(d.price) || 0, image: d.image || '',
    }
  })
}

/**
 * 生成一个不撞车的 id。
 * used 可选：恢复存档时要按"已经收下的 id"判重，
 * 那时 state.menu 还是默认值，直接读它会生成重复 id。
 */
function newDishId(used) {
  const set = used || {}
  if (!used) for (const d of state.menu) set[d.id] = true
  let i = 1
  while (set['x' + i]) i++
  return 'x' + i
}

/**
 * 校验并归一化一道菜。不合法返回 null（调用方负责拒绝保存）。
 * 名称必填；描述可空；价格允许 0（比如"送的"），但必须是有限数。
 */
function normalizeDish(raw, fallbackId) {
  if (!raw || typeof raw !== 'object') return null
  const name = String(raw.name == null ? '' : raw.name).trim().slice(0, NAME_MAX)
  if (!name) return null
  const desc = String(raw.desc == null ? '' : raw.desc).trim().slice(0, DESC_MAX)
  let price = Number(raw.price)
  if (!isFinite(price) || price < 0) price = 0
  price = Math.min(PRICE_MAX, Math.round(price))
  // 图片是一段 data URL。只认 data:image/ 开头，
  // 别的东西（http 链接、乱填的字符串）一律当没有。
  const img = typeof raw.image === 'string' && raw.image.indexOf('data:image/') === 0
    ? raw.image : ''
  return {
    id: String(raw.id || fallbackId || newDishId()),
    name: name, desc: desc, price: price, image: img,
  }
}

/** 新增一道菜。返回是否成功（达到上限或数据不合法会失败）。 */
function addDish(raw) {
  if (state.menu.length >= MENU_LIMIT) return false
  const d = normalizeDish(raw, newDishId())
  if (!d) return false
  state.menu = state.menu.concat([d])
  emit('render')
  return true
}

/** 改一道菜。 */
function updateDish(id, raw) {
  const i = state.menu.findIndex(function (d) { return d.id === id })
  if (i < 0) return false
  const d = normalizeDish(raw, id)
  if (!d) return false
  d.id = id                        // id 不允许被改掉，否则点单会连不上
  const next = state.menu.slice()
  next[i] = d
  state.menu = next
  emit('render')
  return true
}

/** 删一道菜，同时清掉两个人点单里的残留。 */
function removeDish(id) {
  const i = state.menu.findIndex(function (d) { return d.id === id })
  if (i < 0) return false
  state.menu = state.menu.slice(0, i).concat(state.menu.slice(i + 1))
  for (const who of ['a', 'b']) {
    if (state.qty[who] && state.qty[who][id] != null) delete state.qty[who][id]
  }
  // 焦点可能已经越界
  if (focusIndex >= state.menu.length) focusIndex = 0
  emit('render')
  return true
}

/** 恢复出厂菜单。 */
function resetMenu() {
  state.menu = cloneMenu(DEFAULT_MENU)
  focusIndex = 0
  emit('render')
}

/* ---- 编辑器的宿主接口 ----
 * 玻璃渲染器只有文本和按钮，没有文本输入框，所以真正的输入交给
 * DOM 覆盖层（index.html 里的 #dish-editor）。这里只负责弹出去。*/
let editorHost = null      // 由 mount() 注入
let toastHost = null
let undoDish = null        // 最近一次删除，用于撤销

/** 打开编辑器。id 为 null 表示新增。 */
function openDishEditor(id) {
  const dish = id
    ? state.menu.find(function (d) { return d.id === id })
    : null
  // 编辑一个已被删掉的 id（比如撤销前的旧引用）时按新增处理
  state.draft = { id: dish ? dish.id : null, name: dish ? dish.name : '',
    desc: dish ? dish.desc : '', price: dish ? String(dish.price) : '' }
  if (editorHost) editorHost(state.draft)
}

/** 编辑器保存。返回错误文案（null = 成功）。 */
function commitDishEditor(fields) {
  const id = state.draft ? state.draft.id : null
  const image = fields && typeof fields.image === 'string' ? fields.image : ''
  // 存档走 localStorage（约 5MB），图片是最大的风险点。
  // 单张先卡一道，再整体卡一道，超限就让图片退化、保住文字菜单。
  if (image && image.length > DISH_IMG_MAX) {
    return '图片太大了，换一张小一点的'
  }
  const name = String(fields && fields.name != null ? fields.name : '').trim()
  if (!name) return '菜名不能为空'
  if (name.length > NAME_MAX) return '菜名最多 ' + NAME_MAX + ' 个字'
  const desc = String(fields && fields.desc != null ? fields.desc : '').trim()
  if (desc.length > DESC_MAX) return '描述最多 ' + DESC_MAX + ' 个字'
  const raw = String(fields && fields.price != null ? fields.price : '').trim()
  // 允许留空（当作 0，比如"送的"、"自带"），但不能是负数或非数字
  const price = raw === '' ? 0 : Number(raw)
  if (!isFinite(price) || price < 0) return '价格要填 0 或正数'
  if (price > PRICE_MAX) return '价格最多 ' + PRICE_MAX
  const payload = { name: name, desc: desc, price: price, image: image }
  let ok = id ? updateDish(id, payload) : addDish(payload)
  // 写了之后存档超预算：丢掉这张图重试一次，菜单本身保住
  if (ok && image && storeTooBig()) {
    const fallback = { name: name, desc: desc, price: price, image: '' }
    ok = id ? updateDish(id, fallback) : addDish(fallback)
    if (ok) {
      state.draft = null
      return '图片太大，已保存但去掉了图片'
    }
  }
  if (!ok) return id ? '保存失败' : '最多只能加 ' + MENU_LIMIT + ' 道菜'
  state.draft = null
  return null
}

function closeDishEditor() {
  state.draft = null
  if (editorHost) editorHost(null)
}

/** 撤销上一次删除，放回原来的位置。 */
function undoDeleteDish() {
  if (!undoDish) return
  const d = undoDish.dish
  const i = Math.max(0, Math.min(undoDish.index, state.menu.length))
  state.menu = state.menu.slice(0, i).concat([d], state.menu.slice(i))
  undoDish = null
  emit('render')
}

/**
 * 轻提示。带一个可选的动作按钮（用于"确认"和"撤销"）。
 * 交给 DOM 层实现，没注入就静默忽略 —— 功能不能因为提示层缺失而坏掉。
 */
function showToast(msg, onAction, actionLabel) {
  if (toastHost) toastHost(msg, onAction, actionLabel)
}

const PEOPLE = [
  { id: 'a', name: 'H', tag: 'H' },
  { id: 'b', name: 'ZY', tag: 'ZY' },
]

const TABS = [
  { label: '菜单', icon: 'M2.5 10.5h19a9.5 9.5 0 0 1-19 0Z M6 19.2h12a1 1 0 0 1 0 2H6a1 1 0 0 1 0-2Z' },
  { label: '心意', icon: 'M12 20.8 3.7 12.5a5.3 5.3 0 0 1 7.5-7.5l.8.8.8-.8a5.3 5.3 0 0 1 7.5 7.5L12 20.8Z' },
  { label: '账单', icon: 'M6 2h8l5 5v14a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1Zm2 8h9v2H8v-2Zm0 4h9v2H8v-2Zm0 4h6v2H8v-2Z' },
  { label: '归航', icon: 'M12 3 5 14h14L12 3Zm-1.2 3.6v5.2h2.4V6.6h-2.4ZM4 15.4h16v1.7H4v-1.7Zm2.4 3.5h11.2v1.8H6.4v-1.8Z' },
]

/** 归航页的诗句。点一下卡片换下一首。 */
const VERSES = [
  ['Νόστος —— 归返', '海上十年，风浪与神祇，', '都不及推开家门时，', '桌上还留着的那盏灯。'],
  ['卡吕普索的岛', '她许他永生，', '他却在岸边日日远望 ——', '因为那边有人在等。'],
  ['塞壬的歌声', '把耳朵封上蜡也好，', '把身子绑在桅杆上也好，', '有人听见的是归途。'],
  ['珀涅罗珀的织机', '白天织，夜里拆，', '一匹布织了三年，', '只为等你回来的那一天。'],
  ['伊萨卡的餐桌', '不必有山珍海味，', '只要对面坐着的人，', '是绕了十年也想见的那个。'],
]

/* ------------------------------------------------------------------ *
 * 元素工厂
 * ------------------------------------------------------------------ */
function base(id, kind, rect, o) {
  o = o || {}
  return {
    id: id,
    kind: kind,
    rect: rect,
    cornerRadius: o.cornerRadius != null ? o.cornerRadius : Math.min(rect.w, rect.h) / 2,
    refractionHeight: o.refractionHeight != null ? o.refractionHeight : 12,
    refractionAmount: o.refractionAmount != null ? o.refractionAmount : -24,
    depthEffect: o.depthEffect != null ? o.depthEffect : false,
    chromaticAberration: o.chromaticAberration != null ? o.chromaticAberration : false,
    blurRadius: o.blurRadius != null ? o.blurRadius : 2,
    saturation: o.saturation != null ? o.saturation : 1.5,
    brightness: o.brightness != null ? o.brightness : 0,
    contrast: o.contrast != null ? o.contrast : 1,
    tintColor: o.tintColor || [0, 0, 0, 0],
    surfaceColor: o.surfaceColor || [0, 0, 0, 0],
    highlight: o.highlight !== undefined ? o.highlight : HL,
    outerShadow: o.outerShadow !== undefined ? o.outerShadow : null,
    innerShadow: o.innerShadow || null,
    label: o.label || '',
    labelColor: o.labelColor || C.cream,
    labelFontSizePx: o.labelFontSizePx,
    showChevron: false,
    isInteractive: o.isInteractive != null ? o.isInteractive : false,
    pressTintColor: o.pressTintColor || undefined,
    independentBackdrop: o.independentBackdrop != null ? o.independentBackdrop : false,
  }
}

function glass(id, rect, o) {
  return base(id, 'glass-shape', rect, o)
}
function pill(id, rect, o) {
  o = o || {}
  const el = base(id, 'plain-rect', rect, { cornerRadius: o.cornerRadius || 0 })
  el.plainRect = { color: o.color || [1, 1, 1, 0.2] }
  return el
}
/**
 * 希腊回纹（μαίανδρος）—— 一条连续的折线装饰带。
 * 单元内的走线：上 → 右（顶）→ 下 → 左（中）→ 下（到底）→ 右（底，贯通接下一单元）。
 * 几何用 tests/meander.js 以 ASCII 验证过，确认是连续的回纹而非断头笔画。
 *
 * 笔画用 plain-rect 拼，且显式关掉 highlight —— 否则每段都要多跑一遍
 * 高光 pass，几十段叠加起来不划算。
 */
function pushMeander(out, idPrefix, x, y, w, h, color) {
  const U = Math.max(9, Math.round(h * 1.4))     // 单元宽
  const n = Math.max(1, Math.floor(w / U))
  const t = Math.max(0.8, h * 0.12)              // 笔画粗
  const ox = x + (w - n * U) / 2
  const mx = U * 0.7
  const ix = U * 0.3
  const my = h * 0.5
  const unit = [
    { x: 0, y: 0, w: t, h: h },                    // 上（左竖）
    { x: 0, y: 0, w: mx, h: t },                   // 右（顶横）
    { x: mx - t, y: 0, w: t, h: my },              // 下（右竖到中）
    { x: ix, y: my - t, w: mx - ix + t, h: t },    // 左（中横）
    { x: ix, y: my - t, w: t, h: h - my + t },     // 下（内竖到底）
    { x: 0, y: h - t, w: U, h: t },                // 右（底横，贯通）
  ]
  for (let i = 0; i < n; i++) {
    for (let k = 0; k < unit.length; k++) {
      const c = unit[k]
      const el = base(idPrefix + '-' + i + '-' + k, 'plain-rect',
        { x: ox + i * U + c.x, y: y + c.y, w: c.w, h: c.h },
        { cornerRadius: 0, highlight: null })
      el.plainRect = { color: color }
      out.push(el)
    }
  }
}

function label(id, rect, content, o) {
  o = o || {}
  const el = base(id, 'text', rect, o)
  el.text = {
    content: content,
    color: o.color || C.cream,
    fontSizePx: o.fontSizePx || 14,
    fontWeight: o.fontWeight || 400,
    align: o.align || 'left',
    wrap: o.wrap != null ? o.wrap : false,
    paddingPx: o.paddingPx || 0,
    valign: o.valign || 'center',
    maxLines: o.maxLines,
    halo: o.halo || 'dark',
  }
  return el
}
function button(id, rect, text, o) {
  o = o || {}
  const el = base(id, 'button', rect, Object.assign({}, o, {
    label: text,
    isInteractive: true,
    labelFontSizePx: o.fontSizePx,
  }))
  return el
}

/* ------------------------------------------------------------------ *
 * 场景构建
 * ------------------------------------------------------------------ */
function buildScene(state, W, H) {
  const elements = []
  const interactions = {}
  /** 菜品缩略图的落位信息，交给 DOM 覆盖层渲染（见 syncDishPhotos）。 */
  const photoSlots = []
  let scrollInfo = { max: 0, top: 0, bottom: H }

  /* ---- 自适应布局 ----
   * 宽屏（PC）：居中的内容列 + 双列网格，字号与间距整体放大；
   * 窄屏（手机）：单列铺满，保留手机状态栏。 */
  const wide = W >= 820
  const P = wide ? 22 : 16
  const COL_MAX = wide ? 1080 : 620
  const CW = Math.max(280, Math.min(W - (wide ? 2 * P : 0), COL_MAX))
  const X0 = Math.round((W - CW) / 2)
  const L = X0 + P
  const CW_IN = CW - 2 * P
  const cx = X0 + CW / 2
  const cols = wide ? 2 : 1

  const TABS_H = wide ? 68 : 64
  const tabsY = H - TABS_H - (wide ? 36 : 26)
  const top = wide ? 56 : 46
  const bottom = tabsY - (wide ? 24 : 14)
  const warm = state.candle

  /* ---- 顶部状态条 ---- */
  const now = new Date()
  const hh = String(now.getHours()).padStart(2, '0')
  const mm = String(now.getMinutes()).padStart(2, '0')
  if (wide) {
    const sbTime = label('sb-time', { x: X0, y: 0, w: 220, h: 46 }, hh + ':' + mm, {
      fontSizePx: 15, paddingPx: P, color: C.cream, fontWeight: 500,
    })
    sbTime.noEnter = true
    elements.push(sbTime)
    const WD = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']
    const sbDate = label('sb-date', { x: X0 + CW - 300, y: 0, w: 300, h: 46 },
      WD[now.getDay()] + ' · ' + (now.getMonth() + 1) + '月' + now.getDate() + '日 · 爱琴海之夜', {
      fontSizePx: 12.5, paddingPx: P, color: C.creamDim, align: 'right',
    })
    sbDate.noEnter = true
    elements.push(sbDate)
    const sbRule = pill('sb-rule', { x: X0 + P, y: top - 8, w: CW_IN, h: 1 },
      { color: [1, 1, 1, 0.12] })
    sbRule.noEnter = true
    elements.push(sbRule)
  } else {
    const sbTimeM = label('sb-time', { x: 0, y: 0, w: 130, h: 44 }, hh + ':' + mm, {
      fontSizePx: 14, paddingPx: 26, color: C.cream, fontWeight: 500,
    })
    sbTimeM.noEnter = true
    elements.push(sbTimeM)
    for (let i = 0; i < 3; i++) {
      const sg = pill('sb-sig' + i, { x: W - 92 + i * 6, y: 22 - (5 + i * 3), w: 3.5, h: 5 + i * 3 }, {
        color: [1, 1, 1, 0.75],
      })
      sg.noEnter = true
      elements.push(sg)
    }
    const bo = pill('sb-bat-out', { x: W - 62, y: 16, w: 24, h: 12 }, { color: [1, 1, 1, 0.28] })
    bo.noEnter = true
    elements.push(bo)
    const bi = pill('sb-bat-in', { x: W - 60, y: 18, w: 16, h: 8 },
      { color: warm ? [0.98, 0.72, 0.3, 0.95] : [0.94, 0.78, 0.45, 0.9] })
    bi.noEnter = true
    elements.push(bi)
  }

  /* ---- 页头 ---- */
  // 细空格做字距：渲染器的字体是写死的，没法设 letter-spacing，
  // 但标题这种短文本插 U+2009 就能拿到 tracking，观感差别很明显。
  const TR = '\u2009'
  const titles = [
    { t: ('ODYSSEY').split('').join(TR), s: '两个人的餐桌 · 爱琴海之夜' },
    { t: ('心意').split('').join(TR), s: '两条航线，同一张餐桌' },
    { t: ('账单').split('').join(TR), s: '这一餐的分量' },
    { t: ('归航').split('').join(TR), s: ('Νόστος').split('').join(TR) },
  ]
  const head = titles[state.tab] || titles[0]
  const headTop = wide ? top + 6 : top + 6
  const hdTitle = label('hd-title', { x: X0, y: headTop, w: CW, h: wide ? 54 : 40 }, head.t, {
    fontSizePx: wide ? 40 : 30, align: 'center', color: C.gold, fontWeight: 600,
  })
  elements.push(hdTitle)
  elements.push(label('hd-sub', { x: X0, y: headTop + (wide ? 56 : 44), w: CW, h: 24 }, head.s, {
    fontSizePx: wide ? 13.5 : 12, align: 'center', color: C.creamDim,
  }))
  // 希腊回纹装饰带，取代原来那条素线
  const mw2 = wide ? 152 : 112
  const mh2 = wide ? 11 : 9
  pushMeander(elements, 'hd-m', cx - mw2 / 2, headTop + (wide ? 84 : 70), mw2, mh2,
    [0.94, 0.78, 0.45, 0.42])

  const bodyTop = headTop + (wide ? 100 : 84)

  if (state.tab === 0) buildMenu()
  else if (state.tab === 1) buildWish()
  else if (state.tab === 2) buildBill()
  else buildHome()

  /* ---- 底部液态玻璃标签栏 ---- */
  buildTabs()

  /* =================== 页面：菜单 =================== */
  function buildMenu() {
    // 点餐人切换
    const whoW = Math.min(wide ? 220 : (CW_IN - 10) / 2, (CW_IN - 10) / 2)
    const whoX = cx - (2 * whoW + 10) / 2
    PEOPLE.forEach(function (p, i) {
      const on = state.who === p.id
      const id = 'who-' + p.id
      elements.push(button(id, { x: whoX + i * (whoW + 10), y: bodyTop, w: whoW, h: wide ? 46 : 40 }, p.name, {
        cornerRadius: wide ? 23 : 20,
        tintColor: on ? [0.94, 0.78, 0.45, 0.85] : [0, 0, 0, 0],
        surfaceColor: on ? [0, 0, 0, 0] : [1, 1, 1, 0.1],
        labelColor: on ? [0.16, 0.11, 0.03, 1] : C.cream,
        fontSizePx: wide ? 15 : 14,
        highlight: on ? HL_GOLD : HL,
        refractionHeight: 14, refractionAmount: -20, blurRadius: 4,
      }))
      interactions[id] = { onTap: function () { state.who = p.id; emit('render') } }
    })

    // 菜品网格（内容可滚动）
    const listTop = bodyTop + (wide ? 66 : 54)
    const footH = wide ? 140 : 114
    const avail = bottom - listTop - footH
    const gap = wide ? 14 : 10
    const n = menu().length
    // 一道菜都没有时（全删了 / 首次进入还没加），rows 会是 0，
    // 下面所有按 rows 均分的算式都会除以零。单独走空态。
    const rows = Math.max(1, Math.ceil(n / cols))
    const gridW = cols === 2 ? Math.min(CW_IN, 1000) : CW_IN
    const gx = cx - gridW / 2
    const colW = (gridW - gap * (cols - 1)) / cols
    const cardH = Math.max(wide ? 92 : 62,
      Math.min(wide ? 116 : 86, (avail - gap * (rows - 1)) / rows))
    if (n === 0) {
      const emptyH = wide ? 120 : 100
      const ey = listTop + (wide ? 40 : 24)
      const ec = glass('menu-empty', { x: gx, y: ey, w: gridW, h: emptyH }, {
        cornerRadius: wide ? 30 : 26,
        surfaceColor: [1, 1, 1, 0.05],
        blurRadius: 4, refractionHeight: 14, refractionAmount: -20,
        depthEffect: true, highlight: HL,
      })
      ec.useContinuousSdf = true
      elements.push(ec)
      elements.push(label('menu-empty-t', { x: gx + 24, y: ey + (wide ? 30 : 22), w: gridW - 48, h: 28 },
        '菜单是空的', { fontSizePx: wide ? 17 : 15.5, color: C.gold, align: 'center', fontWeight: 500 }))
      elements.push(label('menu-empty-s', { x: gx + 24, y: ey + (wide ? 62 : 50), w: gridW - 48, h: 24 },
        '点下面的「＋ 加一道菜」，写进你们自己的菜', {
        fontSizePx: wide ? 13 : 12, color: C.creamDim, align: 'center' }))
      // 空态直接进编辑模式，否则用户没有入口加菜
      if (!state.editing) state.editing = true
    }
    const clip = { x: 0, y: listTop - 2, w: W, h: Math.max(10, bottom - listTop + 2) }

    menu().forEach(function (d, i) {
      const r = Math.floor(i / cols)
      const c = i % cols
      const x = gx + c * (colW + gap)
      const y = listTop + r * (cardH + gap)
      const q = state.qty[state.who][d.id] || 0
      const card = glass('card-' + d.id, { x: x, y: y, w: colW, h: cardH }, {
        cornerRadius: Math.min(wide ? 28 : 24, cardH / 2),
        surfaceColor: warm ? [0.2, 0.12, 0.06, 0.34] : [0.06, 0.1, 0.17, 0.34],
        // 不加金色 tint：数量控件本身已经能看出点了没，
        // 整张卡染色反而把"选中态"做得太重。
        tintColor: [0, 0, 0, 0],
        blurRadius: 4,
        refractionHeight: 16, refractionAmount: -22,
        saturation: 1.35, depthEffect: true,
        // 7 通道色散（ROYGBV）：液态玻璃最标志性的那道彩虹边
        chromaticAberration: true,
        outerShadow: SHADOW_SOFT,
        highlight: HL,
        isInteractive: true,
        pressTintColor: [1, 1, 1, 1],
      })
      card.useContinuousSdf = true
      card.scroll = true
      card.clipRect = clip
      elements.push(card)
      interactions['card-' + d.id] = {
        onTap: function () {
          // 编辑态下卡片上没有 +/−，点整张卡直接改这道菜，
          // 若仍去加数量，用户会看到数字变了却找不到控件把它减回来。
          if (state.editing) { openDishEditor(d.id); return }
          focusIndex = i
          bump(d.id, 1)
        },
      }

      // 有图时右侧留一个方形缩略图位，文字相应收窄
      const hasImg = !!d.image
      const thumb = hasImg ? Math.min(cardH - 16, wide ? 76 : 64) : 0
      const ctrlW = 104
      // 文字区要在缩略图左侧留 10px 间隙：
      // 缩略图左边缘 = colW - 16 - ctrlW - thumb（相对卡片左边）
      const textW = colW - 20 - ctrlW - 8 - (hasImg ? thumb + 18 : 0)
      // 缩略图位交给 DOM 覆盖层画（渲染器没法给单个元素贴照片），
      // 这里把矩形记下来，draw() 之后再同步过去。
      if (hasImg) {
        photoSlots.push({
          id: d.id, src: d.image,
          x: x + colW - 16 - ctrlW - thumb,
          y: y + (cardH - thumb) / 2,
          w: thumb, h: thumb,
          clip: clip,
        })
      }
      const nm = label('nm-' + d.id, { x: x + 20, y: y + cardH * 0.14, w: textW, h: cardH * 0.34 },
        d.name, { fontSizePx: wide ? 16.5 : 15.5, color: C.cream, fontWeight: 500 })
      const pr = label('pr-' + d.id, { x: x + 20, y: y + cardH * 0.14, w: textW, h: cardH * 0.34 },
        '¥ ' + d.price, { fontSizePx: wide ? 16 : 15, color: C.goldSoft, align: 'right', fontWeight: 500 })
      const ds = label('ds-' + d.id, { x: x + 20, y: y + cardH * 0.48, w: textW, h: cardH * 0.34 },
        d.desc, { fontSizePx: wide ? 12.5 : 11.5, color: C.creamDim })
      // 键盘焦点：给一道菜一道金边，让 +/- 和 [ ] 有可见反馈
      if (i === focusIndex % menu().length) {
        const fl = pill('focus-' + d.id, { x: x + 4, y: y + 4, w: colW - 8, h: cardH - 8 },
          { color: [0.94, 0.78, 0.45, 0.5], cornerRadius: Math.min(wide ? 26 : 22, cardH / 2) })
        fl.scroll = true
        fl.clipRect = clip
        elements.push(fl)
      }
      ;[nm, pr, ds].forEach(function (el) { el.scroll = true; el.clipRect = clip; elements.push(el) })

      // 卡片右侧的操作区：编辑模式下换成 ✎ / ×，否则是 − / 数量 / +
      const cy = y + cardH / 2
      const bx = x + colW - 16 - ctrlW
      const d0 = Math.min(wide ? 38 : 34, cardH - 16)

      if (state.editing) {
        const eW = (ctrlW - 10) / 2
        const edit = button('ed-' + d.id, { x: bx, y: cy - d0 / 2, w: eW, h: d0 }, '✎', {
          cornerRadius: d0 / 2,
          surfaceColor: [1, 1, 1, 0.12],
          labelColor: C.goldSoft,
          fontSizePx: wide ? 17 : 16,
          refractionHeight: 10, refractionAmount: -14, blurRadius: 0,
          highlight: HL_GOLD,
        })
        edit.hitRect = { x: bx - 5, y: cy - 22, w: eW + 10, h: 44 }
        edit.scroll = true
        edit.clipRect = clip
        elements.push(edit)
        interactions['ed-' + d.id] = { onTap: function () { openDishEditor(d.id) } }

        const del = button('rm-' + d.id, { x: bx + eW + 10, y: cy - d0 / 2, w: eW, h: d0 }, '×', {
          cornerRadius: d0 / 2,
          surfaceColor: [0.85, 0.3, 0.26, 0.18],
          labelColor: [1, 0.72, 0.66, 1],
          fontSizePx: wide ? 19 : 18,
          refractionHeight: 10, refractionAmount: -14, blurRadius: 0,
        })
        del.hitRect = { x: bx + eW + 5, y: cy - 22, w: eW + 10, h: 44 }
        del.scroll = true
        del.clipRect = clip
        elements.push(del)
        interactions['rm-' + d.id] = {
          onTap: function () {
            // 删掉之前先记住，误删能撤销（菜单是用户一个个敲出来的，丢不起）
            state.draft = null
            undoDish = { dish: d, index: i }
            removeDish(d.id)
            showToast('已删除「' + d.name + '」· 点这里撤销', function () {
              undoDeleteDish()
            })
          },
        }
      } else {
        const qty = q
        const minus = button('mi-' + d.id, { x: bx, y: cy - d0 / 2, w: d0, h: d0 }, '−', {
          cornerRadius: d0 / 2,
          // 只用亮度区分"有没有点"，不用金色 —— 卡片整体不再被染色
          surfaceColor: qty > 0 ? [1, 1, 1, 0.18] : [1, 1, 1, 0.08],
          tintColor: [0, 0, 0, 0],
          labelColor: qty > 0 ? C.cream : C.creamDim,
          fontSizePx: 18,
          refractionHeight: 10, refractionAmount: -14, blurRadius: 0,
        })
        minus.hitRect = { x: bx - 5, y: cy - 22, w: d0 + 10, h: 44 }
        minus.scroll = true
        minus.clipRect = clip
        elements.push(minus)
        interactions['mi-' + d.id] = { onTap: function () { bump(d.id, -1) } }
        const qtel = label('qt-' + d.id, { x: bx + d0 + 6, y: cy - 12, w: ctrlW - 2 * d0 - 12, h: 24 },
          String(qty), { fontSizePx: 15, align: 'center', color: qty > 0 ? C.cream : C.creamDim, fontWeight: 500 })
        qtel.scroll = true
        qtel.clipRect = clip
        elements.push(qtel)
        const plus = button('pl-' + d.id, { x: bx + ctrlW - d0, y: cy - d0 / 2, w: d0, h: d0 }, '+', {
          cornerRadius: d0 / 2,
          tintColor: [0.94, 0.78, 0.45, 0.72],
          labelColor: [0.16, 0.11, 0.03, 1],
          fontSizePx: 18,
          refractionHeight: 10, refractionAmount: -14, blurRadius: 0,
          highlight: HL_GOLD,
        })
        plus.hitRect = { x: bx + ctrlW - d0 - 5, y: cy - 22, w: d0 + 10, h: 44 }
        plus.scroll = true
        plus.clipRect = clip
        elements.push(plus)
        interactions['pl-' + d.id] = { onTap: function () { bump(d.id, 1) } }
      }
    })

    /* ---- 底部操作区 ---- */
    const listBottom = listTop + rows * cardH + (rows - 1) * gap
    const footY = listBottom + (wide ? 20 : 14)
    const total = grandTotal()
    const count = totalCount()
    let obY = footY + (wide ? 34 : 28)
    let obH = wide ? 54 : 50

    if (state.editing) {
      // 编辑态：加菜 / 恢复默认 / 完成
      const full = state.menu.length >= MENU_LIMIT
      const btnW = Math.min(CW_IN, wide ? 300 : 240)
      const add = button('menu-add', { x: cx - btnW / 2, y: obY, w: btnW, h: obH },
        full ? '已 达 上 限 · ' + MENU_LIMIT + ' 道' : '＋ 加 一 道 菜', {
        cornerRadius: obH / 2,
        tintColor: full ? [0.5, 0.5, 0.55, 0.35] : [0.94, 0.78, 0.45, 0.9],
        labelColor: full ? [1, 1, 1, 0.6] : [0.16, 0.11, 0.03, 1],
        fontSizePx: wide ? 16 : 15,
        refractionHeight: 14, refractionAmount: -20, blurRadius: 3,
        chromaticAberration: !full,
        outerShadow: full ? null : SHADOW_SOFT,
        highlight: HL_GOLD,
      })
      add.scroll = true
      add.clipRect = clip
      elements.push(add)
      interactions['menu-add'] = { onTap: function () { if (!full) openDishEditor(null) } }

      // 「恢复默认」和「完成」并排
      const smallY = obY + obH + (wide ? 12 : 10)
      const smallH = wide ? 44 : 40
      const smallW = Math.min((CW_IN - 10) / 2, wide ? 240 : 200)
      const sx = cx - (2 * smallW + 10) / 2
      const rst = button('menu-reset', { x: sx, y: smallY, w: smallW, h: smallH }, '恢 复 默 认', {
        cornerRadius: smallH / 2,
        surfaceColor: [1, 1, 1, 0.09],
        labelColor: C.creamSoft,
        fontSizePx: wide ? 13.5 : 12.5,
        refractionHeight: 12, refractionAmount: -16, blurRadius: 2,
        highlight: HL,
      })
      rst.scroll = true
      rst.clipRect = clip
      elements.push(rst)
      interactions['menu-reset'] = {
        onTap: function () {
          showToast('恢复成默认菜单？', function () { resetMenu() }, '恢复')
        },
      }
      const done = button('menu-done', { x: sx + smallW + 10, y: smallY, w: smallW, h: smallH }, '完 成', {
        cornerRadius: smallH / 2,
        tintColor: [0.94, 0.78, 0.45, 0.8],
        labelColor: [0.16, 0.11, 0.03, 1],
        fontSizePx: wide ? 13.5 : 12.5,
        refractionHeight: 12, refractionAmount: -16, blurRadius: 2,
        highlight: HL_GOLD,
      })
      done.scroll = true
      done.clipRect = clip
      elements.push(done)
      interactions['menu-done'] = { onTap: function () { state.editing = false; emit('render') } }

      obY = smallY + smallH
      obH = 0
    } else {
      const ftSum = label('ft-sum', { x: L, y: footY, w: CW_IN, h: 24 },
        '共 ' + count + ' 份 · 合计 ¥ ' + total, {
        fontSizePx: wide ? 15 : 13.5, color: C.creamSoft, align: 'center',
      })
      ftSum.scroll = true
      ftSum.clipRect = clip
      elements.push(ftSum)
      const obW = Math.min(CW_IN, wide ? 300 : 240)
      const ob = button('order', { x: cx - obW / 2, y: obY, w: obW, h: obH }, '点 亮 烛 火 · 下 单', {
        cornerRadius: obH / 2,
        tintColor: count > 0 ? [0.94, 0.78, 0.45, 0.9] : [0.5, 0.5, 0.55, 0.35],
        labelColor: count > 0 ? [0.16, 0.11, 0.03, 1] : [1, 1, 1, 0.6],
        fontSizePx: wide ? 16 : 15,
        refractionHeight: 14, refractionAmount: -20, blurRadius: 3,
        chromaticAberration: count > 0,
        outerShadow: count > 0 ? SHADOW_SOFT : null,
        highlight: HL_GOLD,
      })
      ob.scroll = true
      ob.clipRect = clip
      elements.push(ob)
      interactions['order'] = {
        onTap: function () {
          if (count > 0) { state.dialog = ordered(); emit('render'); startEnter() }
        },
      }

      // 「编辑菜单」入口放在合计行右侧，不额外占高度
      const edW = wide ? 96 : 84
      const edH = wide ? 30 : 28
      const ed = button('menu-edit', { x: L + CW_IN - edW, y: footY - (wide ? 4 : 2), w: edW, h: edH }, '编辑菜单', {
        cornerRadius: edH / 2,
        surfaceColor: [1, 1, 1, 0.08],
        labelColor: C.creamDim,
        fontSizePx: wide ? 12 : 11,
        refractionHeight: 10, refractionAmount: -14, blurRadius: 0,
        highlight: HL,
      })
      ed.scroll = true
      ed.clipRect = clip
      elements.push(ed)
      interactions['menu-edit'] = { onTap: function () { state.editing = true; emit('render') } }
    }

    scrollInfo = {
      max: Math.max(0, obY + obH + 18 - bottom),
      top: listTop,
      bottom: bottom,
    }
  }

  /* =================== 页面：心意 =================== */
  function buildWish() {
    const gap = wide ? 16 : 14
    const gridW = cols === 2 ? Math.min(CW_IN, 1000) : CW_IN
    const gx = cx - gridW / 2
    const colW = cols === 2 ? (gridW - gap) / 2 : gridW
    const availH = bottom - bodyTop - (wide ? 60 : 46)
    const cardH = wide
      ? Math.max(200, Math.min(400, availH))
      : Math.max(118, Math.min(250, (availH - 14) / 2))

    const maxRows = Math.max(1, Math.floor((cardH - 62) / 26))
    PEOPLE.forEach(function (p, i) {
      const r = wide ? 0 : i
      const c = wide ? i : 0
      const x = gx + c * (colW + gap)
      const y = bodyTop + r * (cardH + gap)
      const mine = state.qty[p.id]
      const wc = glass('wc-' + p.id, { x: x, y: y, w: colW, h: cardH }, {
        cornerRadius: wide ? 30 : 26,
        surfaceColor: warm ? [0.2, 0.12, 0.06, 0.34] : [0.06, 0.1, 0.17, 0.34],
        blurRadius: 6, refractionHeight: 16, refractionAmount: -22,
        depthEffect: true, highlight: HL,
        chromaticAberration: true, outerShadow: SHADOW_SOFT,
      })
      wc.useContinuousSdf = true
      elements.push(wc)
      elements.push(label('wn-' + p.id, { x: x + 22, y: y + 16, w: colW - 44, h: 30 },
        p.name, { fontSizePx: wide ? 19 : 17, color: C.gold, fontWeight: 600 }))
      elements.push(label('wt-' + p.id, { x: x + 22, y: y + 16, w: colW - 44, h: 30 },
        p.tag + ' 点了 ' + countOf(p.id) + ' 份', {
        fontSizePx: wide ? 13 : 12, color: C.creamDim, align: 'right',
      }))

      const rows = menu().filter(function (d) { return (mine[d.id] || 0) > 0 })
      if (!rows.length) {
        elements.push(label('we-' + p.id, { x: x + 22, y: y + 48, w: colW - 44, h: cardH - 62 },
          '还空着 —— 去菜单里挑一样吧',
          { fontSizePx: wide ? 13.5 : 12.5, color: C.creamDim, valign: 'top' }))
      } else {
        rows.slice(0, maxRows).forEach(function (d, k) {
          const ry = y + 52 + k * 26
          elements.push(label('wl-' + p.id + '-' + d.id, { x: x + 22, y: ry, w: colW - 44 - 90, h: 24 },
            d.name, { fontSizePx: wide ? 14 : 13, color: C.cream, valign: 'center' }))
          elements.push(label('wq-' + p.id + '-' + d.id, { x: x + 22, y: ry, w: colW - 44, h: 24 },
            '× ' + mine[d.id] + '   ¥ ' + mine[d.id] * d.price, {
            fontSizePx: wide ? 13.5 : 12.5, color: C.goldSoft, align: 'right',
          }))
        })
      }
    })

    // 心意相通
    const both = menu().filter(function (d) {
      return (state.qty.a[d.id] || 0) > 0 && (state.qty.b[d.id] || 0) > 0
    })
    const sy = bodyTop + (wide ? cardH + 24 : 2 * cardH + gap + 6)
    if (both.length) {
      // 两个人同时选中 —— 这是整页情绪的落点，给它一枚蜜金玻璃胶囊，
      // 而不是一行素字。
      const bh2 = wide ? 52 : 46
      const bw2 = Math.min(CW_IN, wide ? 560 : CW_IN)
      const capsule = glass('wish-both-card', { x: cx - bw2 / 2, y: sy - 4, w: bw2, h: bh2 }, {
        cornerRadius: bh2 / 2,
        tintColor: [0.94, 0.78, 0.45, 0.14],
        surfaceColor: warm ? [0.24, 0.14, 0.06, 0.3] : [0.07, 0.11, 0.19, 0.3],
        blurRadius: 6, refractionHeight: 14, refractionAmount: -20,
        saturation: 1.4, depthEffect: true,
        chromaticAberration: true,
        highlight: HL_GOLD,
      })
      capsule.useContinuousSdf = true
      elements.push(capsule)
    }
    elements.push(label('wish-both', {
      x: L, y: sy + (both.length ? -4 : 0), w: CW_IN, h: both.length ? (wide ? 52 : 46) : 44,
    },
      both.length
        ? '心意相通 · ' + both.map(function (d) { return d.name }).join('、')
        : '还没有一道菜被两个人同时选中',
      { fontSizePx: wide ? 13.5 : 12, color: both.length ? C.gold : C.creamDim,
        align: 'center', wrap: true, maxLines: 2, valign: 'center' }))
  }

  /* =================== 页面：账单 =================== */
  function buildBill() {
    const total = grandTotal()
    const count = totalCount()
    const cardW = Math.min(CW_IN, wide ? 560 : CW_IN)
    const bx0 = cx - cardW / 2
    const cardH = Math.max(190,
      Math.min(wide ? 330 : 300, bottom - bodyTop - (wide ? 200 : 130)))

    const bcMain = glass('bc-main', { x: bx0, y: bodyTop, w: cardW, h: cardH }, {
      cornerRadius: wide ? 32 : 28,
      surfaceColor: warm ? [0.2, 0.12, 0.06, 0.36] : [0.06, 0.1, 0.17, 0.36],
      blurRadius: 8, refractionHeight: 18, refractionAmount: -24,
      depthEffect: true, highlight: HL,
      chromaticAberration: true, outerShadow: SHADOW,
    })
    bcMain.useContinuousSdf = true
    elements.push(bcMain)
    elements.push(label('bl-cap', { x: bx0, y: bodyTop + 22, w: cardW, h: 22 },
      '这一餐', { fontSizePx: wide ? 13.5 : 12.5, color: C.creamDim, align: 'center' }))
    elements.push(label('bl-total', { x: bx0, y: bodyTop + 46, w: cardW, h: 66 },
      '¥ ' + total, { fontSizePx: wide ? 52 : 42, color: C.gold, align: 'center', fontWeight: 600 }))
    elements.push(pill('bl-rule', { x: cx - 30, y: bodyTop + (wide ? 118 : 112), w: 60, h: 1 },
      { color: [0.94, 0.78, 0.45, 0.4] }))

    PEOPLE.forEach(function (p, i) {
      const ry = bodyTop + (wide ? 132 : 124) + i * (wide ? 30 : 26)
      const amount = amountOf(p.id)
      elements.push(label('blp-' + p.id, { x: bx0 + 26, y: ry, w: cardW - 52, h: 26 },
        p.name + ' · ' + countOf(p.id) + ' 份', { fontSizePx: wide ? 14 : 13, color: C.cream }))
      elements.push(label('bla-' + p.id, { x: bx0 + 26, y: ry, w: cardW - 52, h: 26 },
        '¥ ' + amount, { fontSizePx: wide ? 14 : 13, color: C.goldSoft, align: 'right' }))
    })
    elements.push(label('bl-note', { x: bx0 + 26, y: bodyTop + (wide ? 132 : 124) + 2 * (wide ? 30 : 26) + 4,
      w: cardW - 52, h: 22 },
      count ? '共 ' + count + ' 份 · 平均 ¥ ' + Math.round(total / 2) : '还没有点任何东西',
      { fontSizePx: wide ? 12.5 : 11.5, color: C.creamDim, align: 'center' }))

    // 结算方式
    const spW = Math.min(wide ? 220 : (CW_IN - 10) / 2, (CW_IN - 10) / 2)
    const spX = cx - (2 * spW + 10) / 2
    const spY = bodyTop + cardH + (wide ? 26 : 16)
    ;[['aa', '各自一半'], ['treat', '我请客']].forEach(function (pair, i) {
      const on = state.split === pair[0]
      const id = 'sp-' + pair[0]
      elements.push(button(id, { x: spX + i * (spW + 10), y: spY, w: spW, h: wide ? 48 : 44 }, pair[1], {
        cornerRadius: wide ? 24 : 22,
        tintColor: on ? [0.94, 0.78, 0.45, 0.85] : [0, 0, 0, 0],
        surfaceColor: on ? [0, 0, 0, 0] : [1, 1, 1, 0.1],
        labelColor: on ? [0.16, 0.11, 0.03, 1] : C.cream,
        fontSizePx: wide ? 15 : 14,
        highlight: on ? HL_GOLD : HL,
        refractionHeight: 14, refractionAmount: -20, blurRadius: 4,
      }))
      interactions[id] = { onTap: function () { state.split = pair[0]; emit('render') } }
    })
    elements.push(label('sp-note', { x: L, y: spY + (wide ? 54 : 50), w: CW_IN, h: 22 },
      state.split === 'aa'
        ? '各付 ¥ ' + Math.round(total / 2) + ' · 各自承担自己点的那一份'
        : '由一方买单 ¥ ' + total + ' · 像带回的一份礼物',
      { fontSizePx: wide ? 12.5 : 11.5, color: C.creamDim, align: 'center' }))

    // ---- 账单操作：清空 / 存为图片 ----
    const actW = Math.min(wide ? 200 : (CW_IN - 10) / 2, (CW_IN - 10) / 2)
    const actX = cx - (2 * actW + 10) / 2
    const actY = spY + (wide ? 84 : 78)
    const actH = wide ? 42 : 38
    const hasAny = count > 0

    elements.push(button('bill-clear', { x: actX, y: actY, w: actW, h: actH },
      state.confirmClear ? '再 点 一 次 确 认' : '清 空 这 一 单', {
      cornerRadius: actH / 2,
      surfaceColor: state.confirmClear ? [0.9, 0.35, 0.3, 0.22] : [1, 1, 1, 0.09],
      labelColor: state.confirmClear ? [1, 0.72, 0.66, 1] : C.creamSoft,
      fontSizePx: wide ? 13 : 12,
      refractionHeight: 12, refractionAmount: -16, blurRadius: 2,
      highlight: HL,
    }))
    interactions['bill-clear'] = {
      onTap: function () {
        if (!hasAny) { state.confirmClear = false; emit('render'); return }
        if (state.confirmClear) clearAll()
        else { state.confirmClear = true; emit('render') }
      },
    }

    elements.push(button('bill-export', { x: actX + actW + 10, y: actY, w: actW, h: actH },
      '存 为 图 片', {
      cornerRadius: actH / 2,
      surfaceColor: [1, 1, 1, 0.09],
      labelColor: hasAny ? C.goldSoft : [1, 1, 1, 0.42],
      fontSizePx: wide ? 13 : 12,
      refractionHeight: 12, refractionAmount: -16, blurRadius: 2,
      highlight: HL,
    }))
    interactions['bill-export'] = {
      onTap: function () { if (hasAny) window.__odysseyExportBill() },
    }
  }

  /* =================== 页面：归航 =================== */
  function buildHome() {
    const cardW = Math.min(CW_IN, wide ? 700 : CW_IN)
    const bx0 = cx - cardW / 2
    // 加了导出 / 导入之后，小屏（360x640）放不下整页内容。
    // 与其把卡片越压越小，不如让这一页整体可滚动。
    const homeClip = { x: 0, y: bodyTop - 4, w: W, h: Math.max(10, bottom - bodyTop + 4) }
    const homeStart = elements.length
    const mark = function (el) { el.scroll = true; el.clipRect = homeClip; return el }
    const cardH = Math.max(190,
      Math.min(wide ? 400 : 340, bottom - bodyTop - (wide ? 300 : 250)))
    const hmCard = glass('hm-card', { x: bx0, y: bodyTop, w: cardW, h: cardH }, {
      cornerRadius: wide ? 34 : 30,
      surfaceColor: warm ? [0.24, 0.13, 0.06, 0.4] : [0.06, 0.1, 0.17, 0.36],
      blurRadius: 8, refractionHeight: 18, refractionAmount: -24,
      depthEffect: true, highlight: warm ? HL_GOLD : HL,
      chromaticAberration: true, outerShadow: SHADOW,
    })
    hmCard.useContinuousSdf = true
    elements.push(mark(hmCard))
    const poem = VERSES[state.verse % VERSES.length]
    const vStep = wide ? 40 : 34
    const vTop = bodyTop + (wide ? 40 : 30)
    poem.forEach(function (v, i) {
      elements.push(label('hm-v' + i, { x: bx0 + 26, y: vTop + i * vStep, w: cardW - 52, h: vStep },
        v, {
        fontSizePx: i === 0 ? (wide ? 19 : 16) : (wide ? 16 : 14.5),
        color: i === 0 ? C.gold : C.cream,
        align: 'center', fontWeight: i === 0 ? 600 : 400,
      }))
    })
    // 点卡片换下一首
    interactions['hm-card'] = {
      onTap: function () {
        state.verse = (state.verse + 1) % VERSES.length
        emit('render')
      },
    }
    elements.push(mark(pill('hm-rule', { x: cx - 34, y: vTop + poem.length * vStep + 6, w: 68, h: 1 },
      { color: [0.94, 0.78, 0.45, 0.45] })))
    elements.push(label('hm-hint', { x: bx0 + 26, y: bodyTop + cardH - (wide ? 26 : 22),
      w: cardW - 52, h: 18 },
      '轻触诗句 · 换一首', { fontSizePx: wide ? 11 : 10, color: C.creamDim, align: 'center' }))
    const tail = state.photo
      ? (warm ? '烛火与你们的照片，\n一起铺在这片海上。'
              : '你们的照片，\n正随着这片海缓慢起伏。')
      : (warm ? '烛火已点亮。\n愿你们的餐桌，永远有归处。'
              : '海上风浪很大，\n但餐桌这边一直亮着灯。')
    elements.push(label('hm-tail', { x: bx0 + 26, y: vTop + poem.length * vStep + 18, w: cardW - 52, h: 80 },
      tail, { fontSizePx: wide ? 14.5 : 13, color: warm ? C.goldSoft : C.creamSoft,
        align: 'center', wrap: true, valign: 'top', maxLines: 3 }))

    // ---- 操作按钮：换照片 / 点烛火 / 收起照片 ----
    const hasPhoto = !!state.photo
    const twoW = Math.min(wide ? 300 : 240, (CW_IN - 12) / 2)
    const twoX = cx - (2 * twoW + 12) / 2
    const by = bodyTop + cardH + (wide ? 28 : 22)
    const bh = wide ? 54 : 48

    elements.push(button('pick-photo', { x: twoX, y: by, w: twoW, h: bh },
      hasPhoto ? '换 一 张 照 片' : '放 我 们 的 照 片', {
      cornerRadius: bh / 2,
      tintColor: [0.94, 0.78, 0.45, 0.82],
      labelColor: [0.16, 0.11, 0.03, 1],
      fontSizePx: wide ? 15 : 13.5,
      refractionHeight: 14, refractionAmount: -20, blurRadius: 3,
      chromaticAberration: true,
      highlight: HL_GOLD,
    }))
    interactions['pick-photo'] = { onTap: function () { window.__odysseyPickPhoto() } }

    elements.push(button('candle', { x: twoX + twoW + 12, y: by, w: twoW, h: bh },
      warm ? '熄 灭 烛 火' : '点 亮 烛 火', {
      cornerRadius: bh / 2,
      tintColor: warm ? [0.86, 0.5, 0.2, 0.8] : [1, 1, 1, 0.14],
      surfaceColor: warm ? [0, 0, 0, 0] : [1, 1, 1, 0.08],
      labelColor: warm ? [0.14, 0.09, 0.03, 1] : C.cream,
      fontSizePx: wide ? 15 : 13.5,
      refractionHeight: 14, refractionAmount: -20, blurRadius: 3,
      chromaticAberration: true,
      highlight: warm ? HL_GOLD : HL,
    }))
    interactions['candle'] = { onTap: function () { state.candle = !state.candle; emit('wallpaper'); emit('render') } }

    if (hasPhoto) {
      const cw2 = Math.min(CW_IN, wide ? 260 : 220)
      elements.push(button('clear-photo', { x: cx - cw2 / 2, y: by + bh + 12, w: cw2, h: wide ? 44 : 40 },
        '收 起 照 片 · 回 到 夜 色', {
        cornerRadius: wide ? 22 : 20,
        surfaceColor: [1, 1, 1, 0.1],
        labelColor: C.creamSoft,
        fontSizePx: wide ? 13.5 : 12,
        refractionHeight: 12, refractionAmount: -16, blurRadius: 2,
        highlight: HL,
      }))
      interactions['clear-photo'] = { onTap: function () { window.__odysseyClearPhoto() } }
      elements.push(label('photo-note', { x: L, y: by + bh + (wide ? 62 : 58), w: CW_IN, h: 20 },
        state.photoError
          ? state.photoError
          : '照片已被磨成一片柔光，铺在流动的曲面上', {
        fontSizePx: wide ? 11.5 : 10.5,
        color: state.photoError ? [0.98, 0.62, 0.5, 0.9] : C.creamDim,
        align: 'center',
      }))
    }

    // ---- 背景模式：流体 / 静态 ----
    // 流体自检过不了会自动降级，这里再给一个手动开关，
    // 万一某台设备的驱动有问题，至少能切回有画面的那一版。
    const isFluid = window.__odysseyBgMode ? window.__odysseyBgMode() === 'fluid' : false
    const mw = Math.min(CW_IN, wide ? 300 : 260)
    const my = by + bh + (hasPhoto ? (wide ? 92 : 86) : 14)
    elements.push(button('bg-mode', { x: cx - mw / 2, y: my, w: mw, h: wide ? 40 : 36 },
      isFluid ? '背景 · 流体流动中' : '背景 · 静态夜色', {
      cornerRadius: wide ? 20 : 18,
      surfaceColor: [1, 1, 1, 0.09],
      labelColor: isFluid ? C.goldSoft : C.creamSoft,
      fontSizePx: wide ? 12.5 : 11.5,
      refractionHeight: 10, refractionAmount: -14, blurRadius: 2,
      highlight: HL,
    }))
    interactions['bg-mode'] = {
      onTap: function () {
        window.__odysseySetBgMode(isFluid ? 'static' : 'fluid')
      },
    }

    // ---- 存档：导出 / 导入 ----
    // 放在归航页：这页是"收尾"，且操作不频繁，不会挡住点菜。
    const dw = Math.min(CW_IN, wide ? 300 : 260)
    const dx = cx - (2 * dw + 12 > CW_IN ? dw : 2 * dw + 12) / 2
    const dy = my + (wide ? 56 : 50)
    const dh = wide ? 44 : 40

    elements.push(button('data-export', { x: dx, y: dy, w: dw, h: dh }, '导 出 存 档', {
      cornerRadius: dh / 2,
      surfaceColor: [1, 1, 1, 0.1],
      labelColor: C.creamSoft,
      fontSizePx: wide ? 13.5 : 12.5,
      refractionHeight: 12, refractionAmount: -16, blurRadius: 2,
      highlight: HL,
    }))
    interactions['data-export'] = { onTap: function () { window.__odysseyExportData() } }

    if (wide) {
      elements.push(button('data-import', { x: dx + dw + 12, y: dy, w: dw, h: dh }, '导 入 存 档', {
        cornerRadius: dh / 2,
        surfaceColor: [1, 1, 1, 0.1],
        labelColor: C.creamSoft,
        fontSizePx: 13.5,
        refractionHeight: 12, refractionAmount: -16, blurRadius: 2,
        highlight: HL,
      }))
      interactions['data-import'] = { onTap: function () { window.__odysseyImportData() } }
    } else {
      // 窄屏并排放不下，另起一行
      elements.push(button('data-import', { x: cx - dw / 2, y: dy + dh + 10, w: dw, h: dh }, '导 入 存 档', {
        cornerRadius: dh / 2,
        surfaceColor: [1, 1, 1, 0.1],
        labelColor: C.creamSoft,
        fontSizePx: 12.5,
        refractionHeight: 12, refractionAmount: -16, blurRadius: 2,
        highlight: HL,
      }))
      interactions['data-import'] = { onTap: function () { window.__odysseyImportData() } }
    }

    const note = label('data-note', { x: L, y: dy + (wide ? dh + 10 : 2 * dh + 16),
      w: CW_IN, h: 34 },
      '存档含菜单、菜品图片与点单记录，导出的是一个 JSON 文件', {
      fontSizePx: wide ? 11 : 10, color: C.creamDim, align: 'center', wrap: true, maxLines: 2 })
    elements.push(note)

    // 本页所有元素统一打滚动标记 —— 不用在每个 push 处包 mark，
    // 那样每加一个按钮都要记得包一层，很容易漏。
    let contentBottom = 0
    for (let i = homeStart; i < elements.length; i++) {
      mark(elements[i])
      const r = elements[i].rect
      if (r.y + r.h > contentBottom) contentBottom = r.y + r.h
    }
    // 内容超出可视区就允许滚动
    scrollInfo = {
      max: Math.max(0, contentBottom + (wide ? 24 : 18) - bottom),
      top: bodyTop,
      bottom: bottom,
    }
  }

  /* =================== 底部液态玻璃标签栏 =================== */
  function buildTabs() {
    const barW = Math.min(CW - (wide ? 0 : 48), wide ? 540 : 1e9)
    const containerX = Math.round(cx - barW / 2)
    const containerW = barW
    const GLASS_PAD = 4
    const GLASS_H = TABS_H - 8
    const glassX = containerX + GLASS_PAD
    const glassW = containerW - 2 * GLASS_PAD
    const glassY = tabsY + GLASS_PAD
    const n = TABS.length
    const tabW = glassW / n

    const container = glass('tabs-container', { x: containerX, y: tabsY, w: containerW, h: TABS_H }, {
      cornerRadius: TABS_H / 2,
      refractionHeight: 24, refractionAmount: -24,
      blurRadius: 8, saturation: 1.5,
      surfaceColor: warm ? C.glassWarm : C.glassDark,
      highlight: Object.assign({}, HL, { alpha: 0.5 }),
      depthEffect: true,
      chromaticAberration: true,
      independentBackdrop: true,
    })
    container.isBottomTabContainer = { groupId: 'maintabs', tabsCount: n }
    container.useContinuousSdf = true
    container.noEnter = true
    elements.push(container)

    TABS.forEach(function (t, i) {
      const id = 'tab-' + i
      const on = state.tab === i
      const el = label(id, { x: glassX + tabW * i, y: glassY, w: tabW, h: GLASS_H }, t.label, {
        fontSizePx: wide ? 12 : 11,
        color: on ? C.gold : C.creamSoft,
        align: 'center',
        paddingPx: 0,
        halo: 'dark',
        icon: {
          path: t.icon,
          size: wide ? 24 : 22,
          layoutSize: wide ? 28 : 26,
          viewport: 24,
          color: on ? C.gold : C.creamSoft,
        },
      })
      el.isBottomTabContent = {
        groupId: 'maintabs',
        containerCenterX: containerX + containerW / 2,
        containerCenterY: tabsY + TABS_H / 2,
        containerWidth: containerW,
      }
      el.noEnter = true
      elements.push(el)
      interactions[id] = {
        onTap: function () { selectTab(i) },
        onDragStart: function (ctx) { rendererRef.beginTabDrag('maintabs', state.tab, n) },
        onDrag: function (ctx) { rendererRef.dragTab('maintabs', state.tab, ctx.x, ctx.startX, tabW, n) },
        onDragEnd: function () {
          const idx = rendererRef.endTabDrag('maintabs', n)
          selectTab(Math.max(0, Math.min(n - 1, Math.round(idx))))
        },
      }
    })
    interactions['tabs-container'] = interactions['tab-' + state.tab]

    const indicator = glass('tabs-indicator', { x: glassX, y: glassY, w: tabW, h: GLASS_H }, {
      cornerRadius: GLASS_H / 2,
      refractionHeight: 10, refractionAmount: -14,
      blurRadius: 0, saturation: 1,
      tintColor: [0.94, 0.78, 0.45, 0.16],
      surfaceColor: [0.94, 0.78, 0.45, 0.14],
      highlight: Object.assign({}, HL_GOLD, { alpha: 0.55 }),
      outerShadow: SHADOW_SOFT,
      innerShadow: { radius: 8, alpha: 0.3, offsetX: 0, offsetY: 8 },
      chromaticAberration: true,
    })
    // 必须排除入场动画：底部标签栏是常驻框架。
    // 漏了它的话，每次切页（selectTab → startEnter）指示器都会被
    // 附上一个 enterProgress，渲染器据此把它上移 48dp 再落回 ——
    // 而它同时正在水平滑动到新的页签位置，观感就是"移到一半突然弹起、
    // 凸出栏外再掉回来"。指示器还是 buildTabs 里最后 push 的元素，
    // 在错峰里起步最晚，于是别的东西都落位了它才弹，格外显眼。
    indicator.noEnter = true
    indicator.isBottomTabIndicator = {
      groupId: 'maintabs',
      dragWidth: tabW,
      dimColor: [1, 1, 1, 1],
      accentColor: [0.94, 0.78, 0.45],
      containerRect: { x: glassX - GLASS_PAD, y: glassY, w: glassW + 2 * GLASS_PAD, h: GLASS_H },
      containerCenterX: containerX + containerW / 2,
      containerCenterY: tabsY + TABS_H / 2,
      containerWidth: containerW,
      tabContentIds: TABS.map(function (_, i) { return 'tab-' + i }),
      tabContentRects: TABS.map(function (_, i) {
        return { x: glassX + tabW * i, y: glassY, w: tabW, h: GLASS_H }
      }),
    }
    elements.push(indicator)
  }

  /* =================== 下单对话框 =================== */
  if (state.dialog) {
    const d = state.dialog
    const scrim = pill('dlg-scrim', { x: 0, y: 0, w: W, h: H }, { color: [0.01, 0.02, 0.04, 0.55] })
    scrim.isInteractive = true
    // 遮罩铺满全屏，若跟着入场位移会露出边缘，单独排除，只让它保持原样
    scrim.noEnter = true
    elements.push(scrim)
    const dw = Math.min(W - 48, wide ? 440 : 330)
    const dh = wide ? 330 : 300
    const dx = (W - dw) / 2
    const dy = (H - dh) / 2 - 10
    const dlgCard = glass('dlg-card', { x: dx, y: dy, w: dw, h: dh }, {
      cornerRadius: 34,
      surfaceColor: warm ? [0.22, 0.13, 0.07, 0.62] : [0.08, 0.12, 0.2, 0.62],
      blurRadius: 14, refractionHeight: 22, refractionAmount: -28,
      saturation: 1.4, depthEffect: true,
      chromaticAberration: true,
      outerShadow: { radius: 40, alpha: 0.34, offsetX: 0, offsetY: 14, color: [0, 0, 0] },
      highlight: HL_GOLD,
      isInteractive: true,
    })
    dlgCard.useContinuousSdf = true
        // 弹窗是「弹出」，比常规内容的落位需要更足的弹性
    dlgCard.enterOvershoot = 2.6
elements.push(dlgCard)
    elements.push(label('dlg-t', { x: dx, y: dy + (wide ? 36 : 30), w: dw, h: 32 }, '订单已送出', {
      fontSizePx: wide ? 23 : 20, color: C.gold, align: 'center', fontWeight: 600,
    }))
    elements.push(label('dlg-b', { x: dx + 28, y: dy + (wide ? 82 : 70), w: dw - 56, h: wide ? 150 : 130 }, d.body, {
      fontSizePx: wide ? 14 : 13, color: C.creamSoft, align: 'center', wrap: true, valign: 'top', maxLines: 7,
    }))
    elements.push(label('dlg-no', { x: dx + 28, y: dy + (wide ? 224 : 196), w: dw - 56, h: 20 }, 'No. ' + d.no, {
      fontSizePx: wide ? 12.5 : 11.5, color: C.creamDim, align: 'center',
    }))
    const bw = wide ? 150 : 130
    elements.push(button('dlg-ok', { x: dx + (dw - bw) / 2, y: dy + dh - (wide ? 74 : 66), w: bw, h: wide ? 50 : 46 }, '好', {
      cornerRadius: 23,
      tintColor: [0.94, 0.78, 0.45, 0.9],
      labelColor: [0.16, 0.11, 0.03, 1],
      fontSizePx: wide ? 16 : 15,
      highlight: HL_GOLD,
      refractionHeight: 14, refractionAmount: -20, blurRadius: 3,
    }))
    interactions['dlg-ok'] = { onTap: function () { state.dialog = null; state.candle = true; emit('wallpaper'); selectTab(3) } }
  }

  return {
    elements: elements,
    interactions: interactions,
    scroll: scrollInfo,
    photos: photoSlots,
  }
}

/* ------------------------------------------------------------------ *
 * 状态与小工具
 * ------------------------------------------------------------------ */
function countOf(pid) {
  const m = state.qty[pid]
  let s = 0
  for (const k in m) s += m[k]
  return s
}
function amountOf(pid) {
  const m = state.qty[pid]
  let s = 0
  menu().forEach(function (d) { s += (m[d.id] || 0) * d.price })
  return s
}
function grandTotal() { return amountOf('a') + amountOf('b') }
function totalCount() { return countOf('a') + countOf('b') }
function bump(dishId, delta) {
  const m = state.qty[state.who]
  m[dishId] = Math.max(0, Math.min(99, (m[dishId] || 0) + delta))
  emit('render')
}

/** 清空当前这个人的点单。 */
function clearPerson() {
  state.qty[state.who] = {}
  state.confirmClear = false
  emit('render')
}

/** 清空整单（两个人都清）。 */
function clearAll() {
  state.qty = { a: {}, b: {} }
  state.confirmClear = false
  emit('render')
}
function ordered() {
  const no = String(Math.floor(Math.random() * 9000) + 1000)
  const names = []
  menu().forEach(function (d) {
    const qa = state.qty.a[d.id] || 0
    const qb = state.qty.b[d.id] || 0
    if (qa + qb > 0) names.push(d.name + ' × ' + (qa + qb))
  })
  return {
    no: no,
    body: names.join('\n') + '\n\n合计 ¥ ' + grandTotal() + ' · ' +
      (state.split === 'aa' ? '各自一半' : '由一方买单'),
  }
}

const state = {
  tab: 0,
  who: 'a',
  qty: { a: {}, b: {} },
  split: 'aa',
  candle: false,
  dialog: null,
  scroll: { 0: 0, 1: 0, 2: 0, 3: 0 },
  /** 用户在「归航」上传的照片（objectURL 之外的引用），null = 用默认夜色 */
  photo: null,
  /** 背景模式：'auto'（优先流体，自检不过自动降级）/ 'fluid' / 'static' */
  bgMode: 'auto',
  /** 照片处理失败的原因，用于在页面上给出可见提示 */
  photoError: null,
  /** 归航页当前显示的诗句索引 */
  verse: 0,
  /** 自定义菜单（可增删改），默认取 DEFAULT_MENU */
  menu: cloneMenu(DEFAULT_MENU),
  /** 菜单编辑模式：卡片上显示 ✎ / × 而不是 +/− */
  editing: false,
  /** 正要编辑的菜（null = 新增）。交给 DOM 表单层处理。 */
  draft: null,
  /** 清空订单的二次确认（避免误触把整单点没了） */
  confirmClear: false,
}

/* ------------------------------------------------------------------ *
 * 壁纸 —— 程序化生成的爱琴海夜色 / 烛火暖色
 * ------------------------------------------------------------------ */
function makeWallpaper(candle, W, H) {
  // 按视口比例决定画布尺寸，宽屏 / 竖屏都能 cover 铺满且保留地平线
  const aspect = W && H ? W / H : 0.46
  let w, h
  if (aspect >= 1) { h = 1100; w = Math.round(h * Math.min(aspect, 2.6)) }
  else { h = 1500; w = Math.round(h * Math.max(aspect, 0.38)) }
  const cv = document.createElement('canvas')
  cv.width = w
  cv.height = h
  const g = cv.getContext('2d')
  const SEA = aspect >= 1 ? 0.70 : 0.755   // 地平线所在高度比例
  const starN = Math.round(320 * (w * h) / (780 * 1690))

  const sky = g.createLinearGradient(0, 0, 0, h)
  if (candle) {
    sky.addColorStop(0, '#150805')
    sky.addColorStop(0.28, '#2a1109')
    sky.addColorStop(0.52, '#4d2109')
    sky.addColorStop(0.66, '#8a4a12')
    sky.addColorStop(0.74, '#c8822c')
    sky.addColorStop(0.78, '#3a1a08')
    sky.addColorStop(1, '#120703')
  } else {
    sky.addColorStop(0, '#03060f')
    sky.addColorStop(0.24, '#081029')
    sky.addColorStop(0.46, '#0e2547')
    sky.addColorStop(0.63, '#1a4a78')
    sky.addColorStop(0.74, '#2c6f95')
    sky.addColorStop(0.78, '#0b2138')
    sky.addColorStop(1, '#03060d')
  }
  g.fillStyle = sky
  g.fillRect(0, 0, w, h)

  if (!candle) {
    // 银河
    const mw = g.createLinearGradient(0, 0, w, h * 0.6)
    mw.addColorStop(0, 'rgba(120,160,255,0)')
    mw.addColorStop(0.5, 'rgba(150,180,255,0.10)')
    mw.addColorStop(1, 'rgba(120,160,255,0)')
    g.fillStyle = mw
    g.beginPath()
    g.moveTo(0, h * 0.05)
    g.lineTo(w, h * 0.35)
    g.lineTo(w, h * 0.5)
    g.lineTo(0, h * 0.2)
    g.closePath()
    g.fill()

    // 星
    for (let i = 0; i < starN; i++) {
      const x = Math.random() * w
      const y = Math.random() * h * (SEA - 0.02)
      const r = Math.random() * 1.3 + 0.25
      const a = Math.random() * 0.8 + 0.15
      const tint = Math.random() < 0.22 ? '255,225,170' : '220,235,255'
      g.fillStyle = 'rgba(' + tint + ',' + a + ')'
      g.beginPath()
      g.arc(x, y, r, 0, Math.PI * 2)
      g.fill()
      if (r > 1.15) {
        const gl = g.createRadialGradient(x, y, 0, x, y, r * 9)
        gl.addColorStop(0, 'rgba(' + tint + ',' + a * 0.5 + ')')
        gl.addColorStop(1, 'rgba(' + tint + ',0)')
        g.fillStyle = gl
        g.beginPath()
        g.arc(x, y, r * 9, 0, Math.PI * 2)
        g.fill()
      }
    }
    // 月
    const mx = w * 0.74, my = h * 0.17, mr = 74
    const moon = g.createRadialGradient(mx, my, 0, mx, my, mr)
    moon.addColorStop(0, 'rgba(255,240,205,0.95)')
    moon.addColorStop(0.42, 'rgba(255,232,190,0.55)')
    moon.addColorStop(1, 'rgba(255,225,180,0)')
    g.fillStyle = moon
    g.beginPath()
    g.arc(mx, my, mr, 0, Math.PI * 2)
    g.fill()
  } else {
    // 烛火光晕
    const cx = w * 0.5, cy = h * 0.66
    const gl = g.createRadialGradient(cx, cy, 0, cx, cy, w * 1.1)
    gl.addColorStop(0, 'rgba(255,196,96,0.85)')
    gl.addColorStop(0.35, 'rgba(255,150,50,0.35)')
    gl.addColorStop(1, 'rgba(255,120,30,0)')
    g.fillStyle = gl
    g.fillRect(0, 0, w, h)
    for (let i = 0; i < Math.round(90 * (w * h) / (780 * 1690)); i++) {
      const x = Math.random() * w
      const y = Math.random() * h * 0.5
      const r = Math.random() * 1.6 + 0.3
      g.fillStyle = 'rgba(255,214,150,' + (Math.random() * 0.5 + 0.2) + ')'
      g.beginPath()
      g.arc(x, y, r, 0, Math.PI * 2)
      g.fill()
    }
  }

  // 地平线光带
  const hy = h * SEA
  const band = g.createLinearGradient(0, hy - 90, 0, hy + 60)
  band.addColorStop(0, 'rgba(255,205,130,0)')
  band.addColorStop(0.62, candle ? 'rgba(255,190,110,0.6)' : 'rgba(255,206,140,0.6)')
  band.addColorStop(1, 'rgba(255,180,110,0)')
  g.fillStyle = band
  g.fillRect(0, hy - 90, w, 150)

  // 地平线本身：一道极细的金线，把天空和海分开
  const lineG = g.createLinearGradient(0, hy - 6, 0, hy + 5)
  lineG.addColorStop(0, 'rgba(255,215,150,0)')
  lineG.addColorStop(0.45, candle ? 'rgba(255,224,170,0.85)' : 'rgba(255,222,165,0.8)')
  lineG.addColorStop(1, 'rgba(255,200,130,0)')
  g.fillStyle = lineG
  g.fillRect(0, hy - 6, w, 11)

  // 月光（烛光）在海面上的倒影
  const rx = candle ? w * 0.5 : w * 0.74
  for (let i = 0; i < 64; i++) {
    const t = i / 64
    const y = hy + 8 + Math.pow(t, 1.15) * (h - hy) * 0.92
    const wd = (16 + t * 120) * (1 + Math.sin(i * 1.35) * 0.28)
    const a = (1 - t) * 0.45
    g.fillStyle = candle
      ? 'rgba(255,206,130,' + (a * 0.5) + ')'
      : 'rgba(255,232,190,' + (a * 0.62) + ')'
    g.fillRect(rx - wd / 2 + Math.sin(i * 0.85) * 16, y, wd, 2.6)
  }

  // 海面波纹
  for (let i = 0; i < 90; i++) {
    const t = i / 90
    const y = hy + Math.pow(t, 1.35) * (h - hy)
    const amp = 2 + t * 16
    const alpha = (1 - t) * 0.5 + 0.06
    g.beginPath()
    for (let x = 0; x <= w; x += 8) {
      const yy = y + Math.sin(x * 0.012 + i * 0.8) * amp * 0.4 + Math.sin(x * 0.031 + i * 1.7) * amp * 0.22
      if (x === 0) g.moveTo(x, yy); else g.lineTo(x, yy)
    }
    g.strokeStyle = candle
      ? 'rgba(255,206,140,' + (alpha * 0.5) + ')'
      : 'rgba(190,225,255,' + (alpha * 0.42) + ')'
    g.lineWidth = 0.8 + t * 1.6
    g.stroke()
  }

  // 暗角
  const vig = g.createRadialGradient(w / 2, h * SEA * 0.6, w * 0.2, w / 2, h * 0.5, Math.max(w, h) * 0.72)
  vig.addColorStop(0, 'rgba(0,0,0,0)')
  vig.addColorStop(1, 'rgba(0,0,0,0.55)')
  g.fillStyle = vig
  g.fillRect(0, 0, w, h)

  return cv.toDataURL('image/png')
}

/* ------------------------------------------------------------------ *
 * 流体背景的「封面」——程序生成一张正方形色场
 *
 * 这张图会被 fluid.js 采样到 128×128，再走色调映射 + Kawase 金字塔模糊，
 * 最后贴到 Hermite 曲面上。所以不需要细节，只要大的色彩分布。
 * ------------------------------------------------------------------ */
function makeArtworkSource(warm) {
  const N = 256
  const cv = document.createElement('canvas')
  cv.width = cv.height = N
  const g = cv.getContext('2d')

  const sky = g.createLinearGradient(0, 0, 0, N)
  if (warm) {
    sky.addColorStop(0, '#1a0a04')
    sky.addColorStop(0.30, '#3d1808')
    sky.addColorStop(0.52, '#8a4413')
    sky.addColorStop(0.68, '#d98f3a')
    sky.addColorStop(0.78, '#f0c877')
    sky.addColorStop(0.88, '#5a2a0e')
    sky.addColorStop(1, '#1c0c05')
  } else {
    sky.addColorStop(0, '#03060f')
    sky.addColorStop(0.24, '#081029')
    sky.addColorStop(0.46, '#0e2547')
    sky.addColorStop(0.62, '#1a4a78')
    sky.addColorStop(0.72, '#34789c')
    sky.addColorStop(0.82, '#0b2138')
    sky.addColorStop(1, '#03060d')
  }
  g.fillStyle = sky
  g.fillRect(0, 0, N, N)

  // 地平线的一道金带
  const hy = N * 0.62
  const band = g.createLinearGradient(0, hy - 40, 0, hy + 24)
  band.addColorStop(0, 'rgba(255,205,130,0)')
  band.addColorStop(0.6, warm ? 'rgba(255,200,120,0.75)' : 'rgba(255,214,150,0.6)')
  band.addColorStop(1, 'rgba(255,180,110,0)')
  g.fillStyle = band
  g.fillRect(0, hy - 40, N, 64)

  // 月（或烛火）的光斑 —— 给曲面一个明亮的核
  const cx = warm ? N * 0.5 : N * 0.66
  const cy = warm ? N * 0.58 : N * 0.24
  const r = N * (warm ? 0.42 : 0.30)
  const glow = g.createRadialGradient(cx, cy, 0, cx, cy, r)
  glow.addColorStop(0, warm ? 'rgba(255,226,170,0.95)' : 'rgba(255,242,214,0.9)')
  glow.addColorStop(0.45, warm ? 'rgba(255,170,70,0.45)' : 'rgba(190,215,255,0.35)')
  glow.addColorStop(1, 'rgba(255,150,60,0)')
  g.fillStyle = glow
  g.beginPath()
  g.arc(cx, cy, r, 0, Math.PI * 2)
  g.fill()

  // 海面：几道横向的冷暖交错，让曲面流动时有层次
  for (let i = 0; i < 26; i++) {
    const t = i / 26
    const y = hy + 10 + t * (N - hy - 10)
    g.fillStyle = warm
      ? 'rgba(255,190,110,' + (0.05 + 0.10 * (1 - t)) + ')'
      : 'rgba(150,200,240,' + (0.04 + 0.09 * (1 - t)) + ')'
    g.fillRect(0, y, N, 2 + t * 5)
  }

  // 一点颗粒，避免模糊后过于死板
  for (let i = 0; i < 500; i++) {
    const x = Math.random() * N
    const y = Math.random() * N * 0.6
    g.fillStyle = warm
      ? 'rgba(255,220,160,' + (Math.random() * 0.25) + ')'
      : 'rgba(210,230,255,' + (Math.random() * 0.22) + ')'
    g.fillRect(x, y, 1.4, 1.4)
  }

  // 暗角
  const vig = g.createRadialGradient(N / 2, N / 2, N * 0.25, N / 2, N / 2, N * 0.72)
  vig.addColorStop(0, 'rgba(0,0,0,0)')
  vig.addColorStop(1, 'rgba(0,0,0,0.5)')
  g.fillStyle = vig
  g.fillRect(0, 0, N, N)

  return cv
}

/* ------------------------------------------------------------------ *
 * 宿主：初始化、指针交互、渲染循环
 * ------------------------------------------------------------------ */
let rendererRef = null
let hostEl = null
let canvasEl = null
const listeners = []

/** 键盘焦点落在第几道菜上（buildMenu 在模块作用域，需要模块级变量）。 */
let focusIndex = 0

/* ------------------------------------------------------------------ *
 * 入场动画
 *
 * 渲染器内建了 enterProgress：0 时元素在最终位置上方 48dp，随进度落到位，
 * 同时 enterSafeProgress 驱动透明度。这里按元素顺序错开起跑时间，做出
 * 「依次落位」的节奏 —— 静态堆叠的界面和会入场的界面，观感差别很大。
 *
 * 曲线用带过冲的 outBack：末段越过终点再回落。
 * 这不只是"弹一下"—— 渲染器在 enterProgress > 1 时会自动做
 * squash & stretch，所以过冲段同时给了入场的形变（见 motion.js 头部）。
 * 另外下面还会按瞬时速度额外叠一层纵向拖影。
 * ------------------------------------------------------------------ */
const ENTER_MS = 620
const ENTER_SPREAD = 0.42   // 错开占用整条时间线的比例，其余留给单个元素自己跑完
// 入场拖影：位移 48dp、620ms，缓动导数峰值约 2.4 → 瞬时速度峰值约 190dp/s。
// 用 260 作参考速度，峰值刚好接近满拉伸（约 8%），既看得见又不夸张。
const ENTER_REF_SPEED = 260
const ENTER_MAX_STRETCH = 0.12
const ENTER_SQUASH = 0.38
let enterT = 1              // 1 = 已结束
let enterStart = 0
// draw() / stepMotion 定义在 mount() 闭包里，模块级函数拿不到，用引用桥接
let drawFn = null
let ensureMotionFrameFn = null
let resetMotionBlur = null
let clearDishPhotosFn = null

/** 入场缓动：越过 1 再回落。过冲量随场景可调。 */
function enterEase(t, overshoot) {
  const k = (overshoot == null ? 1.9 : overshoot)
  const u = t - 1
  return 1 + (k + 1) * u * u * u + k * u * u
}

/** 数值求导，用来把缓动的陡峭程度换算成瞬时速度。 */
function enterEaseSlope(t, overshoot) {
  const h = 0.012
  const a = Math.max(0, Math.min(1, t - h))
  const b = Math.max(0, Math.min(1, t + h))
  return (enterEase(b, overshoot) - enterEase(a, overshoot)) / Math.max(1e-4, b - a)
}

function applyEnter(els) {
  if (enterT >= 1) {
    // 收尾：清掉字段，让元素回到「无入场」的常规路径
    for (const el of els) {
      delete el.enterProgress
      delete el.enterSafeProgress
      // 入场写的形变也要清掉，否则元素会永远卡在拉长状态。
      // 动态模糊在之后单独跑，会按需重写。
      delete el.elementScaleX
      delete el.elementScaleY
    }
    return
  }
  // 兜底：底部标签栏的容器 / 页签 / 指示器一律不参与，
  // 哪怕某处漏标了 noEnter 也不会再飞起来。
  const isFrame = function (el) {
    return !!el.noEnter || !!el.isBottomTabContainer ||
      !!el.isBottomTabContent || !!el.isBottomTabIndicator
  }
  let total = 0
  for (const el of els) if (!isFrame(el)) total++
  let idx = 0
  for (const el of els) {
    if (isFrame(el)) {
      delete el.enterProgress
      delete el.enterSafeProgress
      continue
    }
    const i = idx++
    const start = total > 1 ? (i / (total - 1)) * ENTER_SPREAD : 0
    const span = 1 - ENTER_SPREAD
    const t = Math.max(0, Math.min(1, (enterT - start) / span))
    if (t <= 0) {
      // 还没轮到：停在起点且不显示
      el.enterProgress = 0
      el.enterSafeProgress = 0
      continue
    }

    // 过冲强度：弹窗从中心弹出，给它更足的弹性；常规内容克制一些
    const overshoot = el.enterOvershoot != null ? el.enterOvershoot : 1.9
    const e = enterEase(t, overshoot)

    // enterProgress 允许 > 1：渲染器据此做 squash & stretch
    el.enterProgress = e
    // enterSafeProgress 只管透明度，不过冲（渲染器内部也会 clamp 到 [0,1]）
    el.enterSafeProgress = 1 - Math.pow(1 - t, 3)

    // 下落拖影：按瞬时速度纵向拉长、横向收窄。
    // 入场位移是渲染器内部做的，rect 不变，运动追踪器看不见，
    // 所以这里手动补上。
    const slope = Math.abs(enterEaseSlope(t, overshoot))
    const vel = 48 * slope / (ENTER_MS / 1000)   // dp/s
    const k = ENTER_MAX_STRETCH * Math.min(1, vel / ENTER_REF_SPEED)
    if (k > 0.002) {
      el.elementScaleX = (el.elementScaleX == null ? 1 : el.elementScaleX) * (1 - k * ENTER_SQUASH)
      el.elementScaleY = (el.elementScaleY == null ? 1 : el.elementScaleY) * (1 + k)
    }
  }
}

function startEnter() {
  enterT = 0
  enterStart = 0
  // stepMotion 定义在 mount() 闭包里，模块级的 startEnter 拿不到，用引用桥接
  if (ensureMotionFrameFn) ensureMotionFrameFn()
}

/* ------------------------------------------------------------------ *
 * 状态持久化
 * ------------------------------------------------------------------ */

const STORE_KEY = 'odyssey-state'
let saveTimer = 0

/** 存档结构。导出文件与 localStorage 共用同一份，避免两处漂移。 */
function buildSaveData() {
  return {
    // 有版本才能安全地做导入校验
    v: 2,
    savedAt: new Date().toISOString(),
    tab: state.tab,
    who: state.who,
    qty: state.qty,
    split: state.split,
    candle: state.candle,
    verse: state.verse,
    menu: state.menu,
  }
}

function persist() {
  // 合批写：emit('render') 触发得很频繁，每次都同步写 localStorage 会卡。
  if (saveTimer) return
  saveTimer = setTimeout(function () {
    saveTimer = 0
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify(buildSaveData()))
    } catch (e) {
      // 隐私模式或配额满：不影响使用，只是下次打开不记得
    }
  }, 250)
}

/**
 * 把一份存档数据灌进 state。
 * 恢复（localStorage）与导入（文件）共用同一套校验，
 * 避免两处逻辑漂移 —— 导入的数据来自外部，反而要比本地更严格。
 * @returns {String|null} 错误文案，null = 成功
 */
function applySaveData(data) {
  if (!data || typeof data !== 'object') return '数据不是对象'
  // 版本检查：v1（没有 v 字段）是早期版本，结构与现在的差别太大
  if (data.v != null && Number(data.v) > 2) return '存档版本比当前程序新'

  if (data.tab >= 0 && data.tab < TABS.length) state.tab = data.tab
  if (data.who === 'a' || data.who === 'b') state.who = data.who
  if (data.split === 'aa' || data.split === 'treat') state.split = data.split
  if (typeof data.candle === 'boolean') state.candle = data.candle
  if (typeof data.verse === 'number' && data.verse >= 0) state.verse = Math.floor(data.verse)

  // ---- 先恢复菜单 ----
  // 逐条校验，脏数据不能让整页崩掉。
  if (Array.isArray(data.menu)) {
    const seen = {}
    const next = []
    for (const rawItem of data.menu) {
      if (next.length >= MENU_LIMIT) break
      const d = normalizeDish(rawItem, null)
      if (!d) continue                    // 名字空 / 数据坏，跳过
      if (seen[d.id]) d.id = newDishId(seen)  // id 撞车，换一个
      seen[d.id] = true
      next.push(d)
    }
    // 明确传了 menu 但全被过滤掉 —— 说明这份数据有问题，拒绝而不是静默回默认
    if (!next.length && data.menu.length) return '菜单里没有一道合法的菜'
    state.menu = next
  }

  // ---- 再恢复点单 ----
  // 必须在菜单之后：只认当前菜单里存在的菜，
  // 否则菜单被改过之后会留下指不着的残留。
  if (data.qty && typeof data.qty === 'object') {
    for (const who of ['a', 'b']) {
      const src = data.qty[who]
      const dst = {}
      if (src && typeof src === 'object') {
        for (const d of state.menu) {
          const n = Number(src[d.id])
          if (Number.isFinite(n) && n > 0) dst[d.id] = Math.min(99, Math.floor(n))
        }
      }
      state.qty[who] = dst
    }
  } else {
    state.qty = { a: {}, b: {} }
  }

  // 编辑态和草稿不持久化：下次打开应该是干净的浏览态
  state.editing = false
  state.draft = null
  return null
}

function restoreState() {
  let raw = null
  try { raw = localStorage.getItem(STORE_KEY) } catch (e) { return }
  if (!raw) return
  let data
  try { data = JSON.parse(raw) } catch (e) { return }
  if (!data || typeof data !== 'object') return
  const err = applySaveData(data)
  // 本地存档坏了就回到默认，不要卡在坏状态上
  if (err) {
    state.menu = cloneMenu(DEFAULT_MENU)
    state.qty = { a: {}, b: {} }
    state.editing = false
    state.draft = null
  }
}

function emit(evt) {
  for (const fn of listeners) fn(evt)
  if (evt === 'render' || evt === 'wallpaper') persist()
}

function selectTab(i) {
  if (state.tab === i) return
  state.tab = i
  // 切页后同 id 的元素会出现在完全不同的位置（比如卡片换了一列），
  // 不重置的话这个跳变会被当成高速运动，凭空拉出一串拖影。
  // 页面切换的动效交给入场动画，不需要运动模糊来凑。
  if (typeof resetMotionBlur === 'function') resetMotionBlur()
  // 上一页的菜品图必须清掉：下一页可能没有这些菜
  if (clearDishPhotosFn) clearDishPhotosFn()
  if (rendererRef) rendererRef.setTabSelected('maintabs', i, TABS.length)
  emit('render')
  // 切页时让新页面依次落位
  if (typeof startEnter === 'function') startEnter()
}

function hitTest(els, x, y) {
  const sy = rendererRef ? rendererRef.getScrollY() : 0
  for (let i = els.length - 1; i >= 0; i--) {
    const el = els[i]
    if (el.clipRect) {
      const cr = el.clipRect
      if (y < cr.y || y > cr.y + cr.h) continue
    }
    const r = el.hitRect || el.rect
    const y0 = el.scroll ? r.y - sy : r.y
    if (x >= r.x && x <= r.x + r.w && y >= y0 && y <= y0 + r.h) {
      if (!currentInteractions[el.id] && !el.isInteractive) continue
      return el
    }
  }
  return null
}

function scrollRange() {
  return currentScroll ? (currentScroll.max || 0) : 0
}

let currentInteractions = {}
let currentElements = []
let currentScroll = null

function mount(container) {
  // 先恢复上次的点单 / 页面 / 烛火，再做壁纸与首帧
  restoreState()
  try {
    const saved = localStorage.getItem('odyssey-bg-mode')
    if (saved === 'fluid' || saved === 'static' || saved === 'auto') state.bgMode = saved
  } catch (e) {}

  hostEl = container
  canvasEl = container.querySelector('canvas')

  const LG = window.LiquidGlass
  const renderer = new LG.LiquidGlassRenderer(canvasEl)
  rendererRef = renderer
  // 不要设 backgroundColor！
  // renderBackground() 里它是一个硬分支：非空就 drawSolidFill 铺纯色，
  // 完全不走 wallpaper 纹理；连 wallpaperReady 都不等就短路返回。
  // 也就是说一旦设了它，流体背景和静态壁纸都会被这层纯色压死，
  // 屏幕上永远只有那一个底色 —— 表面看就是「背景死黑」。
  // 首帧兜底改由 <body> 的 CSS 底色承担（见 index.html）。
  // renderer.setBackgroundColor(...)   ← 永远不要开
  renderer.dpr = Math.min(window.devicePixelRatio || 1, 2)

  let size = { w: 0, h: 0 }
  let wallAspect = 0

  /* ---------------------------------------------------------------- *
   * 壁纸：优先用 WebGL2 流体背景，否则退回程序生成的静态壁纸
   * ---------------------------------------------------------------- */

  /**
   * 给渲染器补一个"直接从 canvas 上传壁纸"的方法。
   * 上游只有 loadWallpaper(url)，而流体背景每帧都在变，走 dataURL 太慢。
   *
   * 两处针对"每帧上传"的优化：
   *
   *  1. **复用纹理**。原实现每帧 deleteTexture + createTexture + texImage2D，
   *     GL 对象每帧一开一收，是纯粹的 churn。尺寸不变时改用 texSubImage2D
   *     就地覆写，只在尺寸真的变了才重建。
   *
   *  2. **降采样**。壁纸最终会被玻璃模糊、且铺满整屏，细节本来就看不出来。
   *     按 maxEdge 缩小后像素数平方级下降 —— texImage2D 的上传成本、
   *     以及下游模糊重算的成本都跟着降。
   *     降采样画布也复用，不每帧 createElement。
   */
  let pushCanvas = null
  let pushCtx = null
  renderer.loadWallpaperFromCanvas = function (canvas, maxEdge) {
    const gl = this.gl
    if (!gl || !canvas.width || !canvas.height) return

    let src = canvas
    const limit = maxEdge || 0
    const longest = Math.max(canvas.width, canvas.height)
    if (limit > 0 && longest > limit) {
      const k = limit / longest
      const w = Math.max(1, Math.round(canvas.width * k))
      const h = Math.max(1, Math.round(canvas.height * k))
      if (!pushCanvas) {
        pushCanvas = document.createElement('canvas')
        pushCtx = pushCanvas.getContext('2d')
      }
      if (!pushCtx) return
      if (pushCanvas.width !== w || pushCanvas.height !== h) {
        pushCanvas.width = w
        pushCanvas.height = h
      }
      pushCtx.drawImage(canvas, 0, 0, w, h)
      src = pushCanvas
    }

    gl.bindTexture(gl.TEXTURE_2D, this.wallpaperTexture || null)
    const sizeChanged = !this.wallpaperTexture ||
      this.wallpaperSize[0] !== src.width || this.wallpaperSize[1] !== src.height

    if (sizeChanged) {
      if (this.wallpaperTexture) gl.deleteTexture(this.wallpaperTexture)
      const tex = gl.createTexture()
      gl.bindTexture(gl.TEXTURE_2D, tex)
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src)
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR)
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR)
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE)
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)
      this.wallpaperTexture = tex
    } else {
      gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, gl.RGBA, gl.UNSIGNED_BYTE, src)
    }

    this.wallpaperSize = [src.width, src.height]
    this.wallpaperReady = true
    this.clearBackdropBlurCache()
    this.wallpaperVersion++
    this.markAllDirty()
    this.requestRender()
  }

  // 流体背景跑在一块离屏 canvas 上，再按固定间隔投喂给玻璃渲染器。
  // 投喂会清空玻璃的背景模糊缓存，所以频率压得很低：曲面本身 8 秒一个周期，
  // 每 200ms 更新一次在观感上完全连续，却把重算次数降到 5 次/秒。
  const FLUID_PUSH_MS = 200
  let fluid = null
  let fluidCanvas = null
  let wallTimer = 0

  /**
   * 有照片时，烛火不是失效，而是把照片压上一层暖光再喂给流体管线 ——
   * 否则放了照片之后「点亮烛火」这个按钮就没反应了。
   */
  function withCandle(photo, warm) {
    if (!warm) return photo
    const N = 256
    const cv = document.createElement('canvas')
    cv.width = cv.height = N
    const g = cv.getContext('2d')
    const iw = photo.width || photo.naturalWidth || 1
    const ih = photo.height || photo.naturalHeight || 1
    const scale = Math.max(N / iw, N / ih)
    const dw = iw * scale, dh = ih * scale
    g.drawImage(photo, (N - dw) / 2, (N - dh) / 2, dw, dh)
    // 暖光：中心强、边缘弱，像烛火从桌面中心照出去
    g.globalCompositeOperation = 'soft-light'
    const grd = g.createRadialGradient(N / 2, N * 0.62, 0, N / 2, N * 0.62, N * 0.85)
    grd.addColorStop(0, 'rgba(255,178,88,0.85)')
    grd.addColorStop(0.55, 'rgba(255,140,50,0.45)')
    grd.addColorStop(1, 'rgba(255,110,30,0.18)')
    g.fillStyle = grd
    g.fillRect(0, 0, N, N)
    g.globalCompositeOperation = 'source-over'
    return cv
  }

  function currentArtwork() {
    if (state.photo) return withCandle(state.photo, state.candle)
    return makeArtworkSource(state.candle)
  }

  // 照片身份：只有真的换了才重新 setPhoto。
  // 否则每次 resize 都会把 fade/coverage 清零，背景永远停在过渡态。
  let fluidPhotoTag = null
  function artworkTag() {
    const warm = state.candle ? ':warm' : ':cool'
    return state.photo
      ? ('photo:' + (state.photo.width || 0) + 'x' + (state.photo.height || 0) + warm)
      : (state.candle ? 'warm' : 'cool')
  }
  function syncFluidPhoto(force) {
    if (!fluid) return
    const tag = artworkTag()
    if (!force && tag === fluidPhotoTag) return
    fluidPhotoTag = tag
    fluid.setPhoto(currentArtwork())
  }

  let fluidBroken = false

  /* ------------------------------------------------------------------ *
   * 投喂频率自适应
   *
   * 每次投喂都会清空玻璃的背景模糊缓存并重算，这是整条链路上最贵的一步。
   * 频率压得太低（原来固定 200ms = 5fps）背景看着就是卡的；
   * 压太高又会吃掉主线程的帧预算，让点按和滚动变迟钝。
   *
   * 所以按"上传开销最多占 CPU 的多少"来连续调节：
   *   interval = cost / TARGET_LOAD，夹在 [PUSH_MIN_MS, PUSH_MAX_MS]
   * 原来那个"只在 200 和 420 之间跳"的二值逻辑很糟 ——
   * 一旦掉到 420 就很难爬回来，中间地带完全没有档位。
   * ------------------------------------------------------------------ */
  const PUSH_MIN_MS = 28      // ~36fps，再快就没意义了（玻璃模糊重算跟不上）
  const PUSH_MAX_MS = 200     // 5fps，兜底
  const TARGET_LOAD = 0.22    // 上传开销最多占 CPU 的 22%
  let pushMs = 0
  let pushInterval = FLUID_PUSH_MS
  // Worker 模式：一帧在途就不再请求，避免消息堆积
  let frameInFlight = false
  let frameSentAt = 0

  function resetPushTimer() {
    if (wallTimer) { clearInterval(wallTimer); wallTimer = 0 }
    if (!fluid) return
    wallTimer = setInterval(pushFluid, pushInterval)
  }

  function notePushCost(ms) {
    // 指数平滑，避免单帧抖动把频率来回拽
    pushMs = pushMs * 0.75 + ms * 0.25
    const want = Math.max(PUSH_MIN_MS,
      Math.min(PUSH_MAX_MS, Math.round(pushMs / TARGET_LOAD)))
    // 只在变化足够大时才重建定时器（重建本身有成本，且会打断节奏）
    if (Math.abs(want - pushInterval) >= 8) {
      pushInterval = want
      resetPushTimer()
    }
  }

  /** 壁纸上传的目标长边：细节会被玻璃模糊吃掉，不需要上传原始尺寸。 */
  function pushMaxEdge() {
    // 屏幕越大，背景需要的像素越少（反正都要被拉伸铺满再模糊）
    const longest = Math.max(size.w, size.h)
    if (longest >= 1400) return 384
    if (longest >= 900) return 448
    return 512
  }

  // 自愈看门狗：rAF 一旦被节流或停掉，coverage/fade 就永远停在原地，
  // 过渡再也跑不完。这里每轮投喂时比对一次，发现"连续两次完全没动且
  // 还没到位"，就同步把过渡推完。任何原因造成的卡住都能自己恢复。
  let lastConverge = null
  function ensureConverged() {
    if (!fluid || !fluid.converge) return
    let c
    try { c = fluid.converge() } catch (e) { return }
    // Worker 模式下首帧回来之前没有真实状态（known:false），这时不能
    // 判断"卡住"，否则会误触发 settle，也会拿到 undefined 去比较。
    if (!c || c.known === false) return
    const done = (!c.covered && c.coverage === 0) ||
      (c.coverage >= 0.999 && c.fade >= 0.999 && c.transition >= 0.999)
    if (done) { lastConverge = null; return }
    const sig = c.coverage + '|' + c.fade + '|' + c.transition + '|' + c.covered
    if (sig === lastConverge) {
      if (fluid.settle) fluid.settle(1400)
      lastConverge = null
    } else {
      lastConverge = sig
    }
  }

  function pushFluid() {
    if (!fluid) return
    ensureConverged()
    // 只上传，不在这里 render：rAF 循环已经在推进动画了，重复渲染会让
    // 时间流速翻倍。preserveDrawingBuffer=true 保证 buffer 里始终有
    // 最近一帧的内容，直接上传即可。
    // Worker 模式例外：画面在 Worker 手里，主线程拿不到同步结果，
    // 只能请求一帧，等它回传后由 onFrame 上传。
    // 'pending'（Worker 还没握手）时也不能上传 —— 那时 fluidCanvas
    // 是空的，上传等于把壁纸换成一张全黑，启动瞬间会闪死黑。
    const fm = fluid.mode ? fluid.mode() : 'main'
    if (fm === 'worker') {
      // Worker 模式下真正的成本发生在回传之后（见 onFrame），
      // 这里只记一个请求时间戳用于测往返延迟。
      // 但"上一帧还没回来就别再要" —— 否则请求会堆在消息队列里，
      // 回传时主线程要连续处理多帧，反而更卡。
      if (frameInFlight) return
      frameInFlight = true
      frameSentAt = performance.now()
      fluid.requestFrame()
      return
    }
    if (fm === 'pending' || fm === 'failed') return
    const t0 = performance.now()
    try {
      renderer.loadWallpaperFromCanvas(fluidCanvas, pushMaxEdge())
      notePushCost(performance.now() - t0)
    } catch (e) {
      // 上传链路坏了就别反复重试了，直接退回静态壁纸
      fluidBroken = true
      if (wallTimer) { clearInterval(wallTimer); wallTimer = 0 }
      try { fluid.dispose() } catch (e2) {}
      fluid = null
      fluidCanvas = null
      applyWallpaper()
    }
  }

  function applyWallpaper() {
    if (fluidBroken) fluid = null
    const wantFluid = state.bgMode !== 'static' && !!fluid
    if (wantFluid) {
      if (wallTimer) { clearInterval(wallTimer); wallTimer = 0 }
      fluid.resize(size.w, size.h)
      syncFluidPhoto(false)
      // 直接收敛到位，而不是只画一帧：否则启动后头 0.8 秒 coverage 还在
      // 爬升，看到的会是纯色场而不是照片。
      if (fluid.settle) fluid.settle(1400)
      else fluid.renderOnce()
      fluid.start()
      pushFluid()
      if (!wallTimer) resetPushTimer()
      return Promise.resolve()
    }
    if (wallTimer) { clearInterval(wallTimer); wallTimer = 0 }
    if (fluid) { fluid.stop() }
    const url = makeWallpaper(state.candle, size.w, size.h)
    return renderer.loadWallpaper(url).then(function () {
      renderer.requestRender()
    }).catch(function () {
      // 连静态壁纸都加载不了，至少保住底色不是死黑
      renderer.requestRender()
    })
  }

  function layout() {
    const r = container.getBoundingClientRect()
    size = { w: Math.round(r.width), h: Math.round(r.height) }
    canvasEl.style.width = size.w + 'px'
    canvasEl.style.height = size.h + 'px'
    renderer.resize(size.w, size.h)
  }

  clearDishPhotosFn = clearDishPhotos
  resetMotionBlur = function () {
    if (!mblur) return
    try { mblur.reset() } catch (e) {}
  }

  function draw() {
    drawFn = draw
    const scene = buildScene(state, size.w, size.h)
    currentElements = scene.elements
    currentInteractions = scene.interactions
    currentScroll = scene.scroll
    applyEnter(scene.elements)
    // 动态模糊：必须在 setElements 之前，因为它是就地写 elementScaleX/Y
    applyMotionBlur(scene.elements)
    renderer.setElements(scene.elements)
    renderer.setContentHeight(size.h + (scene.scroll.max || 0))
    renderer.setScrollY(state.scroll[state.tab] || 0)
    // 缩略图位置依赖 scrollY，必须在 setScrollY 之后同步
    syncDishPhotos(scene.photos, state.scroll[state.tab] || 0)
    renderer.requestRender()
  }

  /* ---- 菜品图片覆盖层 ----
   * 渲染器只有一块全局 SDF 贴图（距离场），没法给单个元素贴照片，
   * 所以缩略图用 DOM <img> 叠在画布上，每帧按卡片矩形定位。 */
  const photoLayer = document.getElementById('dish-photos')
  /** id -> <img>，复用节点，不每帧重建 */
  const photoNodes = new Map()

  function syncDishPhotos(photos, scrollY) {
    if (!photoLayer) return
    const sy = scrollY || 0
    const alive = new Set()

    for (const slot of photos || []) {
      if (!slot || !slot.src) continue
      alive.add(slot.id)

      const clip = slot.clip
      // 被裁剪区裁掉的（滚出可视区）直接隐藏
      let visible = true
      if (clip) {
        const top = slot.y - sy
        if (top + slot.h < clip.y || top > clip.y + clip.h) visible = false
      }

      let img = photoNodes.get(slot.id)
      if (!img) {
        img = document.createElement('img')
        img.alt = ''
        img.decoding = 'async'
        photoLayer.appendChild(img)
        photoNodes.set(slot.id, img)
      }
      if (img.getAttribute('src') !== slot.src) img.setAttribute('src', slot.src)
      if (!visible) { img.style.display = 'none'; continue }
      img.style.display = ''
      img.style.left = slot.x + 'px'
      img.style.top = (slot.y - sy) + 'px'
      img.style.width = slot.w + 'px'
      img.style.height = slot.h + 'px'
    }

    // 清掉不再存在的（删菜、切页、换菜单）
    for (const [id, node] of Array.from(photoNodes.entries())) {
      if (!alive.has(id)) {
        if (node.parentNode) node.parentNode.removeChild(node)
        photoNodes.delete(id)
      }
    }
  }

  /** 彻底清掉（切页时用，避免上一页的图残留）。 */
  function clearDishPhotos() {
    for (const [, node] of photoNodes.entries()) {
      if (node.parentNode) node.parentNode.removeChild(node)
    }
    photoNodes.clear()
  }

  /* ---- 动态模糊 ----
   * 见 motion.js 的头部说明：真正的逐帧模糊会击穿渲染器的 elFbo 缓存，
   * 这里用沿运动方向的各向异性拉伸（smear）作为等价物，零烘焙成本。 */
  const mblur = (window.Motion && window.Motion.MotionBlur)
    ? window.Motion.MotionBlur()
    : null

  let prevScrollY = null
  let prevScrollT = 0

  function applyMotionBlur(els) {
    if (!mblur) return false
    const now = (typeof performance !== 'undefined' ? performance.now() : Date.now())
    let sy = 0
    let sv = 0
    try { if (renderer.getScrollY) sy = renderer.getScrollY() } catch (e) {}
    try { if (renderer.getScrollVelocity) sv = renderer.getScrollVelocity() } catch (e) {}

    // 滚动是渲染器内部的平移，元素 rect 不变，只能把速度注入进来。
    // 惯性（拖动释放）用 getScrollVelocity；滚轮是离散的、没有惯性速度，
    // 所以再按 scrollY 的帧间位移补一份，两者取大的那个。
    if (prevScrollY != null) {
      const dt = Math.max(6, now - prevScrollT)
      const d = (sy - prevScrollY) / (dt / 1000)
      if (Math.abs(d) > Math.abs(sv)) sv = d
    }
    prevScrollY = sy
    prevScrollT = now

    try {
      return mblur.apply(els, {
        now: now,
        velocity: Math.abs(sv) > 1 ? [0, sv] : null,
      })
    } catch (e) {
      return false
    }
  }

  /**
   * 动效帧循环。
   * 入场动画要推进，动态模糊停下后还要出最后一帧把拉伸归零 ——
   * 否则元素会卡在变形状态。两者合用一条循环。
   */
  let motionRaf = 0
  // 独立的 pending 标志：不能拿 rAF 的返回值当守卫。
  // 回调一旦没被执行（标签页隐藏、rAF 被节流），返回值会一直非零，
  // 之后就再也点不起动效循环了。
  let motionPending = false
  ensureMotionFrameFn = ensureMotionFrame
  function ensureMotionFrame() {
    if (motionPending) return
    if (typeof requestAnimationFrame !== 'function') return
    motionPending = true
    motionRaf = requestAnimationFrame(function (now) {
      motionPending = false
      motionRaf = 0
      stepMotion(now)
    })
  }
  function stepMotion(now) {
    if (enterT < 1) {
      if (!enterStart) enterStart = now
      const p = (now - enterStart) / ENTER_MS
      enterT = p >= 1 ? 1 : p
    }
    if (!drawFn) { enterT = 1; return }
    try { drawFn() } catch (e) { enterT = 1; return }
    // 入场还没跑完，或还有元素在形变 —— 继续出帧
    if (enterT < 1 || (mblur && mblur.isActive())) ensureMotionFrame()
  }

  layout()

  // 流体背景（WebGL2）—— 初始化失败或自检不通过就退回静态壁纸
  if (window.FluidBackground && window.FluidBackground.supported) {
    try {
      fluidCanvas = document.createElement('canvas')
      fluid = new window.FluidBackground(fluidCanvas, {
        width: size.w, height: size.h,
        // Worker 模式：Worker 回传一帧后画进 fluidCanvas，再上传给玻璃
        onFrame: function () {
          if (!fluid || !fluidCanvas) return
          frameInFlight = false
          const t0 = performance.now()
          try {
            renderer.loadWallpaperFromCanvas(fluidCanvas, pushMaxEdge())
            notePushCost(performance.now() - t0)
          } catch (e) {}
        },
      })
      fluid.setPhoto(currentArtwork())
      fluidPhotoTag = artworkTag()
      // 自检：只声明支持 WebGL2 不代表这套 shader 真能画出东西。
      // 回读一帧的亮度，几乎全黑就认为这条管线不可用，走降级。
      // 阈值取 25：白图在管线正常时输出约 130~180，画不出东西时只剩
      // 清屏色约 6。用小于清屏色的阈值等于没做自检。
      // probe() 返回 -1 表示「无法同步测量」（Worker 模式下画面在
      // Worker 手里）。这时必须放行，交给下面 2.6s 的复查来判 ——
      // 否则会把好端端的 Worker 路径误杀。
      const lum = fluid.probe()
      if (lum >= 0 && lum < 25) {
        fluid.dispose()
        fluid = null
        fluidCanvas = null
      }
    } catch (e) {
      fluid = null
      fluidCanvas = null
    }
  }

  wallAspect = size.w / size.h
  applyWallpaper()
  draw()
  // 首屏也让内容依次落位
  startEnter()

  // 二次复查：白图自检只能证明"能画出东西"，证明不了真实照片也画得对。
  // 等过渡跑完（coverage 0.8s + fade 1.2s）再回读一次真实画面。
  // 阈值 12 —— 清屏色约 6.3，正常画面 25+，两者之间取值。
  setTimeout(function () {
    if (!fluid || fluidBroken) return
    let lum = -1
    try { lum = fluid.sampleLuma() } catch (e) { lum = -1 }
    if (lum >= 0 && lum < 12) {
      if (wallTimer) { clearInterval(wallTimer); wallTimer = 0 }
      try { fluid.dispose() } catch (e) {}
      fluid = null
      fluidCanvas = null
      fluidBroken = true
      applyWallpaper()
    }
  }, 2600)

  // 页面不可见时停掉流体动画，省电
  document.addEventListener('visibilitychange', function () {
    if (!fluid) return
    if (document.hidden) {
      fluid.setPaused(true)
      fluid.stop()
      if (wallTimer) { clearInterval(wallTimer); wallTimer = 0 }
    } else {
      fluid.setPaused(false)
      fluid.start()
      if (!wallTimer && fluid) resetPushTimer()
    }
  })

  // 恢复上次放的照片（晚一点再恢复，避免和首帧的壁纸竞争）
  setTimeout(restorePhoto, 400)

  /* ---- 键盘操作（PC） ---- */
  // 全键盘可用：Tab 切页、Esc 关弹窗、+/- 调当前菜、Enter 下单。
  window.addEventListener('keydown', function (e) {
    // 输入框里不抢键
    const t = e.target
    if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return
    const k = e.key

    // Esc 关弹窗 / 编辑器 / 取消二次确认
    if (k === 'Escape') {
      if (state.draft) { closeDishEditor(); e.preventDefault() }
      else if (state.dialog) { state.dialog = null; emit('render'); e.preventDefault() }
      else if (state.confirmClear) { state.confirmClear = false; emit('render'); e.preventDefault() }
      return
    }
    // 编辑器打开时，键盘操作全部让给输入框
    if (state.draft) return
    if (state.dialog) {
      if (k === 'Enter' || k === ' ') {
        state.dialog = null
        state.candle = true
        emit('wallpaper')
        selectTab(3)
        e.preventDefault()
      }
      return
    }

    // 1..4 直达四个页面
    if (k >= '1' && k <= String(TABS.length)) {
      selectTab(Number(k) - 1)
      e.preventDefault()
      return
    }
    // ← → 翻页
    if (k === 'ArrowRight' || k === 'ArrowLeft') {
      const d = k === 'ArrowRight' ? 1 : -1
      selectTab((state.tab + d + TABS.length) % TABS.length)
      e.preventDefault()
      return
    }

    // 菜单页：Tab 切换点餐人，+/- 调整第一道菜
    if (state.tab === 0) {
      // 编辑态下没有计数控件，点菜快捷键必须一起屏蔽，
      // 否则会改到看不见的数量上。
      if (state.editing) {
        if (k === 'Escape') { state.editing = false; emit('render'); e.preventDefault() }
        return
      }
      if (k === 'Tab') {
        state.who = state.who === 'a' ? 'b' : 'a'
        emit('render')
        e.preventDefault()
        return
      }
      if (k === 'Enter') {
        const c = totalCount()
        if (c > 0) { state.dialog = ordered(); emit('render') }
        e.preventDefault()
        return
      }
      // +/- 或 ↑↓ 调整当前高亮的那道菜（默认第一道）
      let delta = 0
      if (k === '+' || k === '=' || k === 'ArrowUp') delta = 1
      else if (k === '-' || k === '_' || k === 'ArrowDown') delta = -1
      if (delta !== 0 && menu().length) {
        bump(menu()[focusIndex % menu().length].id, delta)
        e.preventDefault()
        return
      }
      // 数字键已用于切页，这里用 [ ] 在菜品间移动焦点
      if (k === ']' || k === '[') {
        focusIndex = (focusIndex + (k === ']' ? 1 : menu().length - 1)) % menu().length
        emit('render')
        e.preventDefault()
        return
      }
    }

    // 归航页：C 切烛火，V 换诗
    if (state.tab === 3) {
      if (k === 'c' || k === 'C') {
        state.candle = !state.candle
        emit('wallpaper')
        emit('render')
        e.preventDefault()
      } else if (k === 'v' || k === 'V') {
        state.verse = (state.verse + 1) % VERSES.length
        emit('render')
        e.preventDefault()
      }
    }
  })

  /* ---- 拖拽上传：PC 上直接把图片拖进窗口 ---- */
  function pickFromDrop(e) {
    const dt = e.dataTransfer
    if (!dt) return null
    if (dt.files && dt.files.length) {
      for (const f of dt.files) {
        if (/^image\//.test(f.type || '')) return f
      }
      return null
    }
    return null
  }
  // 必须阻止默认行为，否则浏览器会直接打开这张图，页面被替换掉
  window.addEventListener('dragover', function (e) {
    e.preventDefault()
    if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy'
  })
  window.addEventListener('drop', function (e) {
    e.preventDefault()
    const file = pickFromDrop(e)
    if (!file) return
    loadPhoto(file)
    // 拖完顺手带到「归航」，让变化立刻可见
    if (typeof selectTab === 'function' && state.tab !== 3) selectTab(3)
  })

  /* ---- 照片选择（一个隐藏的 file input） ---- */
  const fileInput = document.createElement('input')
  fileInput.type = 'file'
  fileInput.accept = 'image/*'
  fileInput.style.position = 'fixed'
  fileInput.style.left = '-9999px'
  document.body.appendChild(fileInput)
  fileInput.addEventListener('change', function () {
    const file = fileInput.files && fileInput.files[0]
    fileInput.value = ''
    if (!file) return
    loadPhoto(file)
  })
  /* ---------------------------------------------------------------- *
   * 存档导出 / 导入
   * 导出的是一个 JSON 文件；导入会整体替换当前状态。
   * ---------------------------------------------------------------- */
  let dataFileInput = null

  function stamp() {
    const d = new Date()
    const p = function (n) { return (n < 10 ? '0' : '') + n }
    return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) +
      '-' + p(d.getHours()) + p(d.getMinutes())
  }

  function downloadText(filename, text) {
    try {
      const blob = new Blob([text], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = filename
      document.body.appendChild(a)
      a.click()
      // 立刻 revoke 在部分浏览器会拿不到内容，延后一拍
      setTimeout(function () {
        if (a.parentNode) a.parentNode.removeChild(a)
        URL.revokeObjectURL(url)
      }, 1000)
      return true
    } catch (e) { return false }
  }

  window.__odysseyExportData = function () {
    let text = ''
    try { text = JSON.stringify(buildSaveData(), null, 2) } catch (e) {
      showToast('导出失败：状态无法序列化'); return
    }
    const name = 'odyssey-' + stamp() + '.json'
    if (downloadText(name, text)) {
      // 下载可能被浏览器拦掉，给一个兜底：新窗口打开
      showToast('已导出 ' + name, function () {
        try { window.open('data:application/json;charset=utf-8,' + encodeURIComponent(text)) } catch (e) {}
      }, '另存')
    } else {
      showToast('导出失败，换个浏览器试试')
    }
  }

  window.__odysseyImportData = function () {
    if (!dataFileInput) {
      dataFileInput = document.createElement('input')
      dataFileInput.type = 'file'
      dataFileInput.accept = 'application/json,.json'
      dataFileInput.addEventListener('change', function () {
        const f = dataFileInput.files && dataFileInput.files[0]
        dataFileInput.value = ''      // 允许连续选同一个文件
        if (!f) return
        const fr = new FileReader()
        fr.onload = function () {
          let data = null
          try { data = JSON.parse(String(fr.result)) } catch (e) {
            showToast('这个文件不是合法的 JSON'); return
          }
          const err = applySaveData(data)
          if (err) { showToast('导入失败：' + err); return }
          // 导入是整体替换，必须立刻落盘，否则刷新会回到旧状态
          try { localStorage.setItem(STORE_KEY, JSON.stringify(buildSaveData())) } catch (e) {}
          clearDishPhotos()
          emit('wallpaper')
          emit('render')
          startEnter()
          showToast('已导入 ' + state.menu.length + ' 道菜')
        }
        fr.onerror = function () { showToast('读取文件失败') }
        fr.readAsText(f)
      })
    }
    dataFileInput.click()
  }

  window.__odysseyPickPhoto = function () { fileInput.click() }

  // 上一张照片的 object URL，换图时回收
  let photoUrl = null

  // ---- 照片持久化 ----
  // 流体管线最多只用 128×128，所以存一张 256 的缩略图就够还原观感，
  // 体积也能压在几十 KB，localStorage 放得下。
  const PHOTO_KEY = 'odyssey-photo'

  function savePhoto(bitmap) {
    try {
      const N = 256
      const cv = document.createElement('canvas')
      cv.width = cv.height = N
      const g = cv.getContext('2d')
      const iw = bitmap.width || bitmap.naturalWidth || 1
      const ih = bitmap.height || bitmap.naturalHeight || 1
      const scale = Math.max(N / iw, N / ih)
      const dw = iw * scale, dh = ih * scale
      g.drawImage(bitmap, (N - dw) / 2, (N - dh) / 2, dw, dh)
      localStorage.setItem(PHOTO_KEY, cv.toDataURL('image/jpeg', 0.82))
    } catch (e) {
      // 配额满或隐私模式下写不了，忽略即可，不影响使用
    }
  }

  function restorePhoto() {
    let url = null
    try { url = localStorage.getItem(PHOTO_KEY) } catch (e) { return }
    if (!url) return
    const img = new Image()
    img.onload = function () { applyPhoto(img, true) }
    img.src = url
  }

  function loadPhoto(file) {
    state.photoError = null

    // 用 <img> 解码，而不是 createImageBitmap：
    //   · <img> 会自动套用 EXIF 方向；createImageBitmap 默认
    //     imageOrientation:'none'，iPhone 竖拍的照片会直接躺倒 90°。
    //   · <img> 在各家 WebView（含老版本）里兼容性最好。
    const url = URL.createObjectURL(file)
    const img = new Image()
    img.onload = function () {
      if (photoUrl && photoUrl !== url) {
        try { URL.revokeObjectURL(photoUrl) } catch (e) {}
      }
      photoUrl = url
      applyPhoto(img)
    }
    img.onerror = function () {
      try { URL.revokeObjectURL(url) } catch (e) {}
      state.photoError = '这张图读不出来（换 JPG / PNG 试试）'
      emit('render')
    }
    img.src = url
  }

  function applyPhoto(bitmap, skipSave) {
    try {
      state.photo = bitmap
      state.photoError = null
      if (!skipSave) savePhoto(bitmap)
      if (fluid) {
        syncFluidPhoto(true)
        // 关键：用固定步长把过渡跑完，不依赖 rAF。
        // 挑照片时 rAF 常被节流甚至停掉，coverage/fade 会永远停在 0，
        // 照片混不进来 —— 这就是"放了照片背景却没反应"的根因。
        if (fluid.settle) fluid.settle(1400)
        fluid.setPaused(false)
        fluid.start()
        pushFluid()
        if (!wallTimer) resetPushTimer()
      } else {
        applyWallpaperFromPhoto(bitmap)
      }
    } catch (e) {
      // 任何一步失败都不要留半坏状态：退回之前的背景并给出提示
      state.photoError = (e && e.message) ? e.message : String(e)
      state.photo = null
      try { if (fluid) syncFluidPhoto(true) } catch (e2) {}
    }
    emit('render')
  }

  function applyWallpaperFromPhoto(bitmap) {
    // 无 WebGL2 时的兜底：把照片按 cover 画成一张壁纸
    const cv = document.createElement('canvas')
    const w = 780, h = 1690
    cv.width = w; cv.height = h
    const g = cv.getContext('2d')
    const iw = bitmap.width || 1, ih = bitmap.height || 1
    const scale = Math.max(w / iw, h / ih)
    const dw = iw * scale, dh = ih * scale
    g.drawImage(bitmap, (w - dw) / 2, (h - dh) / 2, dw, dh)
    g.fillStyle = 'rgba(2,3,6,0.45)'
    g.fillRect(0, 0, w, h)
    renderer.loadWallpaper(cv.toDataURL('image/png')).then(function () {
      renderer.requestRender()
    })
  }

  /**
   * 把这一单画成一张 PNG 存下来。
   * WebView 里 a[download] 有时不生效，所以同时把图片打开到新标签页，
   * 至少能长按保存（APK 里这条路径是有效的）。
   */
  window.__odysseyExportBill = function () {
    const total = grandTotal()
    const count = totalCount()
    if (!count) return

    const W = 1080, H = 1440
    const cv = document.createElement('canvas')
    cv.width = W; cv.height = H
    const g = cv.getContext('2d')
    if (!g) return

    // 背景：与页面同一套夜色
    const warm = state.candle
    const sky = g.createLinearGradient(0, 0, 0, H)
    if (warm) {
      sky.addColorStop(0, '#150805'); sky.addColorStop(0.5, '#8a4a12')
      sky.addColorStop(0.72, '#c8822c'); sky.addColorStop(0.78, '#3a1a08')
      sky.addColorStop(1, '#120703')
    } else {
      sky.addColorStop(0, '#03060f'); sky.addColorStop(0.45, '#0e2547')
      sky.addColorStop(0.72, '#2c6f95'); sky.addColorStop(0.8, '#0b2138')
      sky.addColorStop(1, '#03060d')
    }
    g.fillStyle = sky
    g.fillRect(0, 0, W, H)

    const GOLD = '#f0c877'
    const CREAM = '#f0e8d6'
    const cx = W / 2
    const M = 90
    let y = 150

    g.textAlign = 'center'
    g.fillStyle = GOLD
    g.font = '600 44px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif'
    g.fillText('ODYSSEY', cx, y); y += 40
    g.fillStyle = 'rgba(240,232,214,0.55)'
    g.font = '24px -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif'
    g.fillText('两个人的餐桌', cx, y); y += 70

    // 合计
    g.fillStyle = GOLD
    g.font = '600 96px -apple-system, "PingFang SC", sans-serif'
    g.fillText('¥ ' + total, cx, y); y += 56
    g.fillStyle = 'rgba(240,232,214,0.5)'
    g.font = '22px -apple-system, "PingFang SC", sans-serif'
    g.fillText('共 ' + count + ' 份', cx, y); y += 60

    // 分隔线
    g.fillStyle = 'rgba(240,200,119,0.35)'
    g.fillRect(cx - 60, y, 120, 2); y += 60

    // 两个人各自点了什么
    g.textAlign = 'left'
    for (const p of PEOPLE) {
      const items = menu().filter(function (d) { return (state.qty[p.id] || {})[d.id] > 0 })
      g.fillStyle = CREAM
      g.font = '600 30px -apple-system, "PingFang SC", sans-serif'
      g.fillText(p.name, M, y)
      g.textAlign = 'right'
      g.fillStyle = GOLD
      g.font = '30px -apple-system, "PingFang SC", sans-serif'
      g.fillText('¥ ' + amountOf(p.id), W - M, y)
      g.textAlign = 'left'
      y += 44

      if (!items.length) {
        g.fillStyle = 'rgba(240,232,214,0.35)'
        g.font = '22px -apple-system, "PingFang SC", sans-serif'
        g.fillText('还没有点', M, y); y += 36
      } else {
        for (const d of items) {
          const q = state.qty[p.id][d.id]
          g.fillStyle = 'rgba(240,232,214,0.8)'
          g.font = '24px -apple-system, "PingFang SC", sans-serif'
          g.fillText(d.name + '  ×' + q, M + 10, y)
          g.textAlign = 'right'
          g.fillStyle = 'rgba(240,232,214,0.6)'
          g.fillText('¥ ' + d.price * q, W - M, y)
          g.textAlign = 'left'
          y += 38
        }
      }
      y += 26
    }

    // 结算方式
    y += 10
    g.textAlign = 'center'
    g.fillStyle = 'rgba(240,200,119,0.85)'
    g.font = '26px -apple-system, "PingFang SC", sans-serif'
    g.fillText(state.split === 'aa'
      ? '各自一半 · 各付 ¥ ' + Math.round(total / 2)
      : '我请客 · ¥ ' + total, cx, y)
    y += 70

    // 日期 + 一句诗
    const now = new Date()
    const stamp = now.getFullYear() + '.' +
      String(now.getMonth() + 1).padStart(2, '0') + '.' +
      String(now.getDate()).padStart(2, '0')
    g.fillStyle = 'rgba(240,232,214,0.4)'
    g.font = '22px -apple-system, "PingFang SC", sans-serif'
    g.fillText(stamp, cx, y); y += 50
    g.fillStyle = 'rgba(240,200,119,0.6)'
    g.font = 'italic 26px -apple-system, "PingFang SC", serif'
    const poem = VERSES[state.verse % VERSES.length]
    g.fillText(poem[poem.length - 1], cx, y)

    const url = cv.toDataURL('image/png')
    try {
      const a = document.createElement('a')
      a.href = url
      a.download = 'odyssey-' + stamp + '.png'
      document.body.appendChild(a)
      a.click()
      if (a.parentNode) a.parentNode.removeChild(a)
    } catch (e) {}
    // 兜底：下载不生效时至少能打开看
    try { window.open(url, '_blank') } catch (e) {}
  }

  /* ---------------------------------------------------------------- *
   * 自定义菜的编辑面板（DOM）
   * 玻璃渲染器里没有文本输入框，所以输入层用 DOM 覆盖。
   * 面板只在编辑时显示，平时完全不参与渲染。
   * ---------------------------------------------------------------- */
  /** 图片压成 dataURL 用的目标长边。菜品缩略图只有 76px，
   *  存原图会让存档膨胀到几十 MB —— localStorage 直接写满。 */
  const DISH_IMG_EDGE = 320
  let draftPhoto = ''

  function shrinkImage(file) {
    return new Promise(function (resolve, reject) {
      const img = new Image()
      img.onload = function () {
        try {
          const iw = img.naturalWidth || img.width || 1
          const ih = img.naturalHeight || img.height || 1
          const k = Math.min(1, DISH_IMG_EDGE / Math.max(iw, ih))
          const w = Math.max(1, Math.round(iw * k))
          const h = Math.max(1, Math.round(ih * k))
          const cv = document.createElement('canvas')
          cv.width = w
          cv.height = h
          const g = cv.getContext('2d')
          if (!g) { resolve(''); return }
          g.drawImage(img, 0, 0, w, h)
          // JPEG 质量 0.82：缩略图看不出差别，体积却小很多
          resolve(cv.toDataURL('image/jpeg', 0.82))
        } catch (e) { reject(e) }
      }
      img.onerror = function () { reject(new Error('图片解码失败')) }
      // 用 <img> 而不是 createImageBitmap：前者会自动套用 EXIF 方向，
      // 手机竖拍的照片不会躺倒
      const fr = new FileReader()
      fr.onload = function () { img.src = String(fr.result) }
      fr.onerror = function () { reject(new Error('读取文件失败')) }
      fr.readAsDataURL(file)
    })
  }

  const edEl = document.getElementById('dish-editor')
  const edForm = document.getElementById('dish-form')
  const edTitle = document.getElementById('dish-editor-title')
  const edName = document.getElementById('dish-name')
  const edDesc = document.getElementById('dish-desc')
  const edPrice = document.getElementById('dish-price')
  const edErr = document.getElementById('dish-err')

  editorHost = function (draft) {
    if (!edEl) return
    if (!draft) { edEl.classList.remove('show'); return }
    edTitle.textContent = draft.id ? '改这道菜' : '加一道菜'
    edName.value = draft.name || ''
    edDesc.value = draft.desc || ''
    edPrice.value = draft.price || ''
    edErr.textContent = ''
    draftPhoto = draft.image || ''
    syncDraftPreview()
    edEl.classList.add('show')
    // 移动端键盘弹出需要焦点；延迟一拍避免和点击冲突
    setTimeout(function () { try { edName.focus() } catch (e) {} }, 60)
  }

  if (edForm) {
    edForm.addEventListener('submit', function (e) {
      e.preventDefault()
      const err = commitDishEditor({
        name: edName.value, desc: edDesc.value, price: edPrice.value,
        image: draftPhoto,
      })
      if (err) { edErr.textContent = err; return }
      edEl.classList.remove('show')
    })
  }
  if (edEl) {
    // 点遮罩空白处关闭（点面板本身不关）
    edEl.addEventListener('mousedown', function (e) {
      if (e.target === edEl) closeDishEditor()
    })
  }
  const edPreview = document.getElementById('dish-photo-preview')
  const edPick = document.getElementById('dish-photo-pick')
  const edClear = document.getElementById('dish-photo-clear')
  const edFile = document.getElementById('dish-photo-file')

  function syncDraftPreview() {
    if (!edPreview) return
    if (draftPhoto) {
      edPreview.setAttribute('src', draftPhoto)
      edPreview.removeAttribute('hidden')
    } else {
      edPreview.removeAttribute('src')
      edPreview.setAttribute('hidden', '')
    }
  }
  syncDraftPreview()

  if (edPick && edFile) {
    edPick.addEventListener('click', function () { edFile.click() })
    edFile.addEventListener('change', function () {
      const f = edFile.files && edFile.files[0]
      edFile.value = ''            // 允许连续选同一个文件
      if (!f) return
      if (!/^image\//.test(f.type || '')) { edErr.textContent = '请选择图片文件'; return }
      edErr.textContent = '处理中…'
      shrinkImage(f).then(function (url) {
        if (!url) { edErr.textContent = '图片处理失败'; return }
        draftPhoto = url
        syncDraftPreview()
        edErr.textContent = ''
      }).catch(function (e) {
        edErr.textContent = (e && e.message) ? e.message : '图片处理失败'
      })
    })
  }
  if (edClear) {
    edClear.addEventListener('click', function () {
      draftPhoto = ''
      syncDraftPreview()
    })
  }

  const edCancel = document.getElementById('dish-cancel')
  if (edCancel) edCancel.addEventListener('click', function () { closeDishEditor() })

  /* ---- 轻提示 ---- */
  const toastEl = document.getElementById('toast')
  const toastMsg = document.getElementById('toast-msg')
  const toastGo = document.getElementById('toast-go')
  let toastTimer = 0
  let toastAction = null

  toastHost = function (msg, onAction, label) {
    if (!toastEl || !toastMsg || !toastGo) {
      // 提示层缺失就直接执行，不能让功能消失
      if (onAction) onAction()
      return
    }
    toastMsg.textContent = msg
    toastAction = onAction || null
    if (onAction) {
      toastGo.style.display = ''
      toastGo.textContent = label || '撤销'
    } else {
      toastGo.style.display = 'none'
    }
    toastEl.classList.add('show')
    if (toastTimer) clearTimeout(toastTimer)
    toastTimer = setTimeout(function () {
      toastEl.classList.remove('show')
      toastAction = null
    }, onAction ? 5000 : 2600)
  }
  if (toastGo) {
    toastGo.addEventListener('click', function () {
      const fn = toastAction
      toastAction = null
      toastEl.classList.remove('show')
      if (fn) fn()
    })
  }

  window.__odysseyElements = function () { return currentElements }

  window.__odysseyDiag = function () {
    const d = fluid ? fluid.diagnose() : null
    return {
      mode: (fluid && !fluidBroken && state.bgMode !== 'static') ? 'fluid' : 'static',
      broken: !!fluidBroken,
      bgMode: state.bgMode,
      hasPhoto: !!state.photo,
      photoError: state.photoError,
      fluid: d,
    }
  }

  window.__odysseySetBgMode = function (mode) {
    if (mode !== 'fluid' && mode !== 'static' && mode !== 'auto') return
    state.bgMode = mode
    try { localStorage.setItem('odyssey-bg-mode', mode) } catch (e) {}
    // 显式选流体时，即便之前自检判过不可用也再试一次
    if (mode === 'fluid') fluidBroken = false
    applyWallpaper()
    emit('render')
  }
  window.__odysseyBgMode = function () {
    return (fluid && !fluidBroken && state.bgMode !== 'static') ? 'fluid' : 'static'
  }

  window.__odysseyClearPhoto = function () {
    state.photo = null
    state.photoError = null
    try { localStorage.removeItem(PHOTO_KEY) } catch (e) {}
    if (fluid) {
      syncFluidPhoto(true)
      if (fluid.settle) fluid.settle(1400)
      pushFluid()
    } else {
      applyWallpaper()
    }
    emit('render')
  }

  // tab 指示器初始位置
  renderer.setTabSelected('maintabs', state.tab, TABS.length)

  let ro = null
  if (window.ResizeObserver) {
    ro = new ResizeObserver(function () {
      const prev = size.w
      layout()
      // 宽窄切换（列数变化）或横竖切换时，壁纸需要按新比例重画
      if ((prev >= 820) !== (size.w >= 820) || wallAspect !== size.w / size.h) {
        applyWallpaper()
        wallAspect = size.w / size.h
      }
      draw()
    })
    ro.observe(container)
  }

  /* ---- 指针交互 ---- */
  let active = null
  const DRAG_TH = 6
  const SCROLL_TH = 8

  function local(e) {
    const r = canvasEl.getBoundingClientRect()
    return { x: e.clientX - r.left, y: e.clientY - r.top }
  }

  canvasEl.addEventListener('pointerdown', function (e) {
    const p = local(e)
    const el = hitTest(currentElements, p.x, p.y)
    active = {
      id: el ? el.id : null,
      startX: p.x, startY: p.y,
      moved: false, dragging: false, scrollDragging: false,
      scrollable: !!(el && el.scroll) || (!el && scrollRange() > 0),
      scrollStart: renderer.getScrollY(),
      lastY: p.y, lastT: performance.now(), vel: 0,
      inter: el ? (currentInteractions[el.id] || null) : null,
      isTab: !!(el && (el.isBottomTabContent || el.isBottomTabContainer)),
    }
    if (el && !active.isTab) renderer.setPressed(el.id, true, { x: p.x, y: p.y })
    e.preventDefault()
  })

  window.addEventListener('pointermove', function (e) {
    if (!active) return
    const p = local(e)
    const dx = p.x - active.startX
    const dy = p.y - active.startY
    const now = performance.now()
    const dt = Math.max(1, now - active.lastT)
    active.vel = (p.y - active.lastY) / dt * 1000
    active.lastY = p.y
    active.lastT = now

    if (!active.moved && Math.abs(dx) + Math.abs(dy) > DRAG_TH) active.moved = true

    // 垂直拖动 → 内容滚动
    if (!active.dragging && active.scrollable && Math.abs(dy) > SCROLL_TH) {
      active.scrollDragging = true
      if (active.id && !active.isTab) renderer.setPressed(active.id, false)
    }
    if (active.scrollDragging) {
      renderer.setScrollY(active.scrollStart - dy)
      state.scroll[state.tab] = renderer.getScrollY()
      // 滚动时要持续出帧，否则动态模糊不会更新
      ensureMotionFrame()
      return
    }

    if (active.moved && active.inter && active.inter.onDragStart && !active.dragging) {
      active.dragging = true
      active.inter.onDragStart({ x: p.x, y: p.y, startX: active.startX, startY: active.startY })
    }
    if (active.dragging && active.inter && active.inter.onDrag) {
      active.inter.onDrag({ x: p.x, y: p.y, dx: dx, dy: dy, startX: active.startX, startY: active.startY })
    }
  })

  function finish(e, cancelled) {
    if (!active) return
    const a = active
    active = null
    if (a.scrollDragging) {
      renderer.setScrollVelocity(-a.vel)
      state.scroll[state.tab] = renderer.getScrollY()
      // 惯性滑行期间也要出帧，让拉伸跟着速度衰减
      ensureMotionFrame()
      return
    }
    if (a.dragging) {
      if (a.inter && a.inter.onDragEnd) a.inter.onDragEnd()
    } else if (!cancelled && a.inter && a.inter.onTap) {
      a.inter.onTap()
    }
    if (a.id && !a.isTab) renderer.setPressed(a.id, false)
  }
  window.addEventListener('pointerup', function (e) { finish(e, false) })
  window.addEventListener('pointercancel', function (e) { finish(e, true) })

  // 桌面：滚轮滚动内容
  canvasEl.addEventListener('wheel', function (e) {
    if (!currentScroll || !(currentScroll.max > 0)) return
    renderer.setScrollY(renderer.getScrollY() + e.deltaY)
    state.scroll[state.tab] = renderer.getScrollY()
    // 滚轮没有惯性速度，但拉伸需要几帧才衰减完，所以先把循环点起来
    ensureMotionFrame()
    e.preventDefault()
  }, { passive: false })

  // 阻止长按选中 / 右键菜单
  canvasEl.addEventListener('contextmenu', function (e) { e.preventDefault() })
  canvasEl.style.touchAction = 'none'

  listeners.push(function (evt) {
    if (evt === 'render') draw()
    else if (evt === 'wallpaper') {
      // 有照片时烛火改变的是 artwork 本身，需要重新生成并投喂
      if (fluid) syncFluidPhoto(true)
      applyWallpaper()
    }
  })

  // 时钟
  setInterval(function () {
    draw()
  }, 20000)

  return renderer
}

if (typeof window !== 'undefined') {
  window.__odysseyMount = mount
  window.__makeWallpaper = makeWallpaper
  window.__odysseySelectTab = selectTab
}

if (typeof module !== 'undefined' && module.exports) {
  // 导出菜单操作，便于自动化测试直接验证校验逻辑
  module.exports = {
    buildScene: buildScene, state: state, DEFAULT_MENU: DEFAULT_MENU,
    MENU: DEFAULT_MENU, TABS: TABS, PEOPLE: PEOPLE,
    menu: menu, addDish: addDish, updateDish: updateDish, removeDish: removeDish,
    resetMenu: resetMenu, normalizeDish: normalizeDish, newDishId: newDishId,
    restoreState: restoreState, applySaveData: applySaveData,
    buildSaveData: buildSaveData, clearAll: clearAll,
    MENU_LIMIT: MENU_LIMIT, NAME_MAX: NAME_MAX, DESC_MAX: DESC_MAX, PRICE_MAX: PRICE_MAX,
  }
}
