# 推到 GitHub

本地仓库已经建好、代码也已全部提交，**只差最后一步：关联远程并推送**。
这一步需要你的账号授权，我这边做不了。

## 一、建仓库

在 GitHub 上新建一个空仓库（**不要**勾 README、.gitignore、LICENSE ——
勾了会多一次提交，第一次推送会被拒）。

建好之后你会拿到一个地址，形如：

```
https://github.com/KV112023/odyssey-couple-ordering.git
```

## 二、推上去

在本工程的 `repo/` 目录下执行：

```bash
git remote add origin https://github.com/KV112023/odyssey-couple-ordering.git
git push -u origin master
```

**注意分支名**：GitHub 新建仓库的默认分支通常是 `main`，
而本地这份是 `master`。如果提示没有匹配分支，用这条：

```bash
git branch -M main
git push -u origin main
```

## 三、用 Token 推送（推荐）

GitHub 已经不再接受账号密码推送，需要用 Personal Access Token。

1. GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
2. Generate new token，勾选 `repo`
3. 推送时用户名填你的 GitHub 用户名，密码填这个 Token

或者在地址里直接带上（**别把这个地址提交进任何文件**）：

```bash
git remote set-url origin https://<TOKEN>@github.com/KV112023/odyssey-couple-ordering.git
git push -u origin master
```

## 四、之后每次更新

```bash
git add -A
git commit -m "说明改了什么"
git push
```

## 重要：仓库里放的是代码，不是你们的数据

推上去的是界面和逻辑。**你们的菜单、点单记录、去过的地方都存在
浏览器 localStorage 里，不会进仓库。**

要保住数据，请用「归航」页的**导出存档**，存成 JSON 文件自己收好。
换设备或清了浏览器缓存后，用「导入存档」恢复。

## 回档

沙盒崩了、本地文件没了时：

```bash
./restore.sh                                    # 从已关联的远程拉
./restore.sh https://github.com/KV112023/odyssey-couple-ordering
./restore.sh https://raw.githubusercontent.com/.../app.js   # 单文件直取
```

脚本会自动判断默认分支是 main 还是 master，
拉下来后校验 7 个关键文件，少一个就报错退出（不会给你一个残缺的工程）。
